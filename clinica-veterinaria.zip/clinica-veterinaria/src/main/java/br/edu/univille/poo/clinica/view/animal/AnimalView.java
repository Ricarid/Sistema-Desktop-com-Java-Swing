package br.edu.univille.poo.clinica.view.animal;

import br.edu.univille.poo.clinica.control.animal.AnimalController;
import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.util.DataUtil;
import br.edu.univille.poo.clinica.view.componente.ListaUtil;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AnimalView extends JPanel {

    private final AnimalController controller = new AnimalController();
    private final ConteudoPanel conteudo;

    private JTextField campoBusca;
    private DefaultTableModel modeloTabela;
    private JTable tabela;

    public AnimalView(ConteudoPanel conteudo) {
        this.conteudo = conteudo;

        configurarLayout();
        pesquisar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10));

        campoBusca = new JTextField(25);
        campoBusca.putClientProperty("JTextField.placeholderText", "Animal ou tutor");
        JButton botaoPesquisar = new JButton("Pesquisar");
        JButton botaoLimpar = new JButton("Limpar");
        JButton botaoNovo = ListaUtil.destacar(new JButton("Novo animal"));

        JPanel filtros = ListaUtil.filtros();
        filtros.add(new JLabel("Buscar:"));
        filtros.add(campoBusca);
        filtros.add(botaoPesquisar);
        filtros.add(botaoLimpar);

        add(ListaUtil.topo(filtros, botaoNovo), BorderLayout.NORTH);

        modeloTabela = ListaUtil.criarModelo(
                new String[]{"ID", "Nome", "Espécie", "Raça", "Nascimento", "Peso (kg)", "Tutor"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class,
                        String.class, String.class, String.class});
        tabela = ListaUtil.criarTabela(modeloTabela, 60, 160, 110, 160, 100, 90, 240);

        add(ListaUtil.rolagem(tabela), BorderLayout.CENTER);

        ListaUtil.aoDuploClique(tabela, conteudo::mostrarEditarAnimal);

        campoBusca.addActionListener(e -> pesquisar());
        botaoPesquisar.addActionListener(e -> pesquisar());
        botaoLimpar.addActionListener(e -> {
            campoBusca.setText("");
            pesquisar();
        });
        botaoNovo.addActionListener(e -> conteudo.mostrarAdicionarAnimal());
    }

    private void pesquisar() {
        try {
            modeloTabela.setRowCount(0);

            for (Animal animal : controller.pesquisar(campoBusca.getText().trim())) {
                modeloTabela.addRow(new Object[]{
                        animal.getId(),
                        animal.getNome(),
                        animal.getEspecie().getNome(),
                        animal.getRaca() == null ? "" : animal.getRaca(),
                        DataUtil.formatar(animal.getDataNascimento()),
                        animal.getPeso() == null ? "" : String.format("%.1f", animal.getPeso()),
                        animal.getTutor().getNome()
                });
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Erro ao pesquisar animais: " + e.getMessage());
        }
    }
}
