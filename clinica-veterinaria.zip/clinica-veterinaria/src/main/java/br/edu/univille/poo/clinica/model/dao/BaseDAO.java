package br.edu.univille.poo.clinica.model.dao;

import java.sql.Connection;
import java.sql.SQLException;

public class BaseDAO {

    protected Connection connection() throws SQLException {
        return ConnectionFactory.getInstance().get();
    }

    protected static String like(String texto) {
        return "%" + (texto == null ? "" : texto.trim()) + "%";
    }

}
