package br.edu.univille.poo.clinica.control.veterinario;

import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.model.usecase.ExcluirVeterinarioUseCase;
import br.edu.univille.poo.clinica.model.usecase.ObterVeterinarioPeloIdUseCase;
import br.edu.univille.poo.clinica.model.usecase.SalvarVeterinarioUseCase;

public class VeterinarioFormController {

    private final SalvarVeterinarioUseCase salvarUseCase = new SalvarVeterinarioUseCase();
    private final ObterVeterinarioPeloIdUseCase obterUseCase = new ObterVeterinarioPeloIdUseCase();
    private final ExcluirVeterinarioUseCase excluirUseCase = new ExcluirVeterinarioUseCase();

    public void salvar(Veterinario veterinario) {
        salvarUseCase.executar(veterinario);
    }

    public Veterinario obterPeloId(Integer id) {
        return obterUseCase.executar(id);
    }

    public void excluir(Integer id) {
        excluirUseCase.executar(id);
    }

}
