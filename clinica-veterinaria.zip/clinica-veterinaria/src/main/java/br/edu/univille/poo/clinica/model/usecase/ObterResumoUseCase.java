package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.dao.TutorDAO;
import br.edu.univille.poo.clinica.model.dao.VeterinarioDAO;
import br.edu.univille.poo.clinica.model.entity.Resumo;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;

import java.time.LocalDate;

public class ObterResumoUseCase {

    private final TutorDAO tutorDAO = new TutorDAO();
    private final AnimalDAO animalDAO = new AnimalDAO();
    private final VeterinarioDAO veterinarioDAO = new VeterinarioDAO();
    private final ConsultaDAO consultaDAO = new ConsultaDAO();

    public Resumo executar() {
        return new Resumo(
                tutorDAO.contar(),
                animalDAO.contar(),
                veterinarioDAO.contarAtivos(),
                consultaDAO.contarPorStatus(StatusConsulta.AGENDADA),
                consultaDAO.contarAgendadasDoDia(LocalDate.now()),
                consultaDAO.somarValorRealizadas()
        );
    }

}
