package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.entity.Animal;

import java.util.List;

public class PesquisarAnimaisUseCase {

    private final AnimalDAO dao = new AnimalDAO();

    public List<Animal> executar(String termo) {
        return dao.pesquisar(termo);
    }

}
