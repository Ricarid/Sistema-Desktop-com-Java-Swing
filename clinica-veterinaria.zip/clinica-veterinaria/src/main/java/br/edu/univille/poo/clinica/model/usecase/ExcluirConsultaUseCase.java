package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;

public class ExcluirConsultaUseCase {

    private final ConsultaDAO dao = new ConsultaDAO();

    public void executar(Integer consultaId) {
        dao.excluir(consultaId);
    }

}
