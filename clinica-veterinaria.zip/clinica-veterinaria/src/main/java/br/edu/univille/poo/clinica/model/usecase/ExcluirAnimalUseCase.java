package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.exception.AnimalComConsultasException;

public class ExcluirAnimalUseCase {

    private final AnimalDAO dao;
    private final ConsultaDAO consultaDAO;

    public ExcluirAnimalUseCase() {
        dao = new AnimalDAO();
        consultaDAO = new ConsultaDAO();
    }

    public void executar(Integer animalId) {
        if (consultaDAO.existePorAnimal(animalId)) {
            throw new AnimalComConsultasException();
        }
        dao.excluir(animalId);
    }

}
