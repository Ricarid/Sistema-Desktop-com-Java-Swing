package br.edu.univille.poo.clinica.view.veterinario;

import br.edu.univille.poo.clinica.control.veterinario.VeterinarioFormController;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.view.componente.FormularioPanel;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import java.awt.*;

public class VeterinarioFormView extends JPanel {

    private final VeterinarioFormController controller = new VeterinarioFormController();
    private final ConteudoPanel conteudo;
    private final Integer id;

    private JTextField campoNome;
    private JTextField campoCrmv;
    private JTextField campoEspecialidade;
    private JCheckBox checkAtivo;

    public VeterinarioFormView(Integer id, ConteudoPanel conteudo) {
        this.id = id;
        this.conteudo = conteudo;

        configurarLayout();
        if (id != null) carregar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout());

        FormularioPanel form = new FormularioPanel(id == null ? "Novo veterinário" : "Editar veterinário");

        campoNome = FormularioPanel.campoTexto(null);
        campoCrmv = FormularioPanel.campoTexto("SC-12345");
        campoEspecialidade = FormularioPanel.campoTexto("Ex.: Clínica geral, Cirurgia (opcional)");
        checkAtivo = new JCheckBox();
        checkAtivo.setSelected(true);

        form.adicionarCampo("Nome:", campoNome);
        form.adicionarCampo("CRMV:", campoCrmv);
        form.adicionarCampo("Especialidade:", campoEspecialidade);
        form.adicionarCampo("Ativo:", checkAtivo);

        JButton botaoCancelar = new JButton("Cancelar");
        JButton botaoSalvar = new JButton("Salvar");
        botaoSalvar.setBackground(UIManager.getColor("Component.accentColor"));
        botaoSalvar.setForeground(Color.WHITE);

        if (id == null) {
            form.adicionarBotoes(botaoCancelar, botaoSalvar);
        } else {
            JButton botaoExcluir = new JButton("Excluir");
            botaoExcluir.addActionListener(e -> excluir());
            form.adicionarBotoes(botaoCancelar, botaoSalvar, botaoExcluir);
        }

        add(form, BorderLayout.CENTER);

        botaoSalvar.addActionListener(e -> salvar());
        botaoCancelar.addActionListener(e -> conteudo.mostrarVeterinarios());
    }

    private void carregar() {
        try {
            Veterinario vet = controller.obterPeloId(id);

            campoNome.setText(vet.getNome());
            campoCrmv.setText(vet.getCrmv());
            campoEspecialidade.setText(vet.getEspecialidade());
            checkAtivo.setSelected(vet.isAtivo());
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar o veterinário. " + e.getMessage());
        }
    }

    private void salvar() {
        Veterinario vet = new Veterinario();
        vet.setId(id);
        vet.setNome(campoNome.getText());
        vet.setCrmv(campoCrmv.getText());
        vet.setEspecialidade(campoEspecialidade.getText());
        vet.setAtivo(checkAtivo.isSelected());

        try {
            controller.salvar(vet);

            conteudo.mostrarVeterinarios();
            conteudo.mensagemNormal("Veterinário salvo com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro(e.getMessage());
        }
    }

    private void excluir() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este veterinário?", "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resposta != JOptionPane.YES_OPTION) return;

        try {
            controller.excluir(id);

            conteudo.mostrarVeterinarios();
            conteudo.mensagemNormal("Veterinário excluído com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível excluir o veterinário. " + e.getMessage());
        }
    }
}
