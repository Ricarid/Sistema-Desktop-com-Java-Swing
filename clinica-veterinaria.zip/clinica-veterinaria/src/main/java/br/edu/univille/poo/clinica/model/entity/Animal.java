package br.edu.univille.poo.clinica.model.entity;

import java.time.LocalDate;

public class Animal {
    private Integer id;
    private String nome;
    private Especie especie;
    private String raca;
    private LocalDate dataNascimento;
    private Double peso;
    private Tutor tutor;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public Especie getEspecie() { return especie; }
    public void setEspecie(Especie especie) { this.especie = especie; }
    public String getRaca() { return raca; }
    public void setRaca(String raca) { this.raca = raca; }
    public LocalDate getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(LocalDate dataNascimento) { this.dataNascimento = dataNascimento; }
    public Double getPeso() { return peso; }
    public void setPeso(Double peso) { this.peso = peso; }
    public Tutor getTutor() { return tutor; }
    public void setTutor(Tutor tutor) { this.tutor = tutor; }

    @Override
    public String toString() {
        return nome + (tutor != null ? " (tutor: " + tutor.getNome() + ")" : "");
    }
}
