package br.edu.univille.poo.clinica.view.principal;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class MenuItem extends JPanel {

    private final JLabel label;

    public MenuItem(Icon icon, String texto) {
        setLayout(new BorderLayout());

        label = new JLabel(texto);
        label.setIcon(icon);
        label.setIconTextGap(12);

        add(label, BorderLayout.CENTER);

        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setOpaque(true);

        selecionar(false);
    }

    public void selecionar(boolean selecionado) {
        Color destaque = UIManager.getColor("Component.accentColor");
        if (destaque == null) destaque = new Color(0x0E8F7E);

        Border margem = BorderFactory.createEmptyBorder(10, 10, 10, 14);

        if (selecionado) {
            setBackground(misturarComBranco(destaque, 0.85f));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 4, 0, 0, destaque), margem));
            label.setFont(label.getFont().deriveFont(Font.BOLD));
        } else {
            setBackground(UIManager.getColor("Panel.background"));
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createEmptyBorder(0, 4, 0, 0), margem));
            label.setFont(label.getFont().deriveFont(Font.PLAIN));
        }
        repaint();
    }

    private static Color misturarComBranco(Color cor, float proporcaoBranco) {
        int r = Math.round(cor.getRed() + (255 - cor.getRed()) * proporcaoBranco);
        int g = Math.round(cor.getGreen() + (255 - cor.getGreen()) * proporcaoBranco);
        int b = Math.round(cor.getBlue() + (255 - cor.getBlue()) * proporcaoBranco);
        return new Color(r, g, b);
    }
}
