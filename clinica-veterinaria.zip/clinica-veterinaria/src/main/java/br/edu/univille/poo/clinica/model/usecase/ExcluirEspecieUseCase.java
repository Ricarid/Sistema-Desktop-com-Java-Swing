package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.dao.EspecieDAO;
import br.edu.univille.poo.clinica.model.exception.EspecieComAnimaisException;

public class ExcluirEspecieUseCase {

    private final EspecieDAO dao;
    private final AnimalDAO animalDAO;

    public ExcluirEspecieUseCase() {
        dao = new EspecieDAO();
        animalDAO = new AnimalDAO();
    }

    public void executar(Integer especieId) {
        if (animalDAO.existePorEspecie(especieId)) {
            throw new EspecieComAnimaisException();
        }
        dao.excluir(especieId);
    }

}
