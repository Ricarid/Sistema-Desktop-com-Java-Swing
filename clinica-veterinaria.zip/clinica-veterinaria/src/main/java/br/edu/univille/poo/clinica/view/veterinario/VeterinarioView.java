package br.edu.univille.poo.clinica.view.veterinario;

import br.edu.univille.poo.clinica.control.veterinario.VeterinarioController;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.view.componente.ListaUtil;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class VeterinarioView extends JPanel {

    private final VeterinarioController controller = new VeterinarioController();
    private final ConteudoPanel conteudo;

    private JTextField campoNome;
    private JCheckBox checkSomenteAtivos;
    private DefaultTableModel modeloTabela;
    private JTable tabela;

    public VeterinarioView(ConteudoPanel conteudo) {
        this.conteudo = conteudo;

        configurarLayout();
        pesquisar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10));

        campoNome = new JTextField(25);
        checkSomenteAtivos = new JCheckBox("Somente ativos", true);
        JButton botaoPesquisar = new JButton("Pesquisar");
        JButton botaoLimpar = new JButton("Limpar");
        JButton botaoNovo = ListaUtil.destacar(new JButton("Novo veterinário"));

        JPanel filtros = ListaUtil.filtros();
        filtros.add(new JLabel("Nome:"));
        filtros.add(campoNome);
        filtros.add(checkSomenteAtivos);
        filtros.add(botaoPesquisar);
        filtros.add(botaoLimpar);

        add(ListaUtil.topo(filtros, botaoNovo), BorderLayout.NORTH);

        modeloTabela = ListaUtil.criarModelo(
                new String[]{"ID", "Nome", "CRMV", "Especialidade", "Ativo"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class, Boolean.class});
        tabela = ListaUtil.criarTabela(modeloTabela, 60, 300, 120, 250, 80);

        add(ListaUtil.rolagem(tabela), BorderLayout.CENTER);

        ListaUtil.aoDuploClique(tabela, conteudo::mostrarEditarVeterinario);

        campoNome.addActionListener(e -> pesquisar());
        botaoPesquisar.addActionListener(e -> pesquisar());
        botaoLimpar.addActionListener(e -> {
            campoNome.setText("");
            checkSomenteAtivos.setSelected(true);
            pesquisar();
        });
        botaoNovo.addActionListener(e -> conteudo.mostrarAdicionarVeterinario());
    }

    private void pesquisar() {
        try {
            modeloTabela.setRowCount(0);

            for (Veterinario vet : controller.pesquisar(campoNome.getText().trim(), checkSomenteAtivos.isSelected())) {
                modeloTabela.addRow(new Object[]{
                        vet.getId(),
                        vet.getNome(),
                        vet.getCrmv(),
                        vet.getEspecialidade() == null ? "" : vet.getEspecialidade(),
                        vet.isAtivo()
                });
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Erro ao pesquisar veterinários: " + e.getMessage());
        }
    }
}
