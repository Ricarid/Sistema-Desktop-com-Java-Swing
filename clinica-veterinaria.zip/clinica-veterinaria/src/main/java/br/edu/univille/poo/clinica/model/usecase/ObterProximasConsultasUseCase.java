package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.entity.Consulta;

import java.util.List;

public class ObterProximasConsultasUseCase {

    private final ConsultaDAO dao = new ConsultaDAO();

    public List<Consulta> executar(int limite) {
        return dao.proximasAgendadas(limite);
    }

}
