package br.edu.univille.poo.clinica.model.dao;

import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.exception.DaoException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EspecieDAO extends BaseDAO {

    private Especie mapear(ResultSet rs) throws SQLException {
        var especie = new Especie();
        especie.setId(rs.getInt("id"));
        especie.setNome(rs.getString("nome"));
        return especie;
    }

    public void inserir(Especie especie) {
        String sql = "INSERT INTO especie (nome) VALUES (?)";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, especie.getNome());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void atualizar(Especie especie) {
        String sql = "UPDATE especie SET nome = ? WHERE id = ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, especie.getNome());
            ps.setInt(2, especie.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void excluir(Integer id) {
        String sql = "DELETE FROM especie WHERE id = ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public Optional<Especie> obterPeloId(Integer id) {
        String sql = "SELECT id, nome FROM especie WHERE id = ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    public Optional<Especie> obterPeloNome(String nome) {
        String sql = "SELECT id, nome FROM especie WHERE nome = ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, nome);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    public List<Especie> obterTodosPeloNome(String nome) {
        var lista = new ArrayList<Especie>();
        String sql = "SELECT id, nome FROM especie WHERE nome LIKE ? ORDER BY nome";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, like(nome));

            try (var rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return lista;
    }

}
