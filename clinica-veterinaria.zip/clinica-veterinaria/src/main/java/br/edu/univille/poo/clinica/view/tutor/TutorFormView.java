package br.edu.univille.poo.clinica.view.tutor;

import br.edu.univille.poo.clinica.control.tutor.TutorFormController;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.util.StringsUtil;
import br.edu.univille.poo.clinica.view.componente.FormularioPanel;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import java.awt.*;

public class TutorFormView extends JPanel {

    private final TutorFormController controller = new TutorFormController();
    private final ConteudoPanel conteudo;
    private final Integer id;

    private JTextField campoNome;
    private JTextField campoCpf;
    private JTextField campoTelefone;
    private JTextField campoEmail;

    public TutorFormView(Integer id, ConteudoPanel conteudo) {
        this.id = id;
        this.conteudo = conteudo;

        configurarLayout();
        if (id != null) carregar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout());

        FormularioPanel form = new FormularioPanel(id == null ? "Novo tutor" : "Editar tutor");

        campoNome = FormularioPanel.campoTexto(null);
        campoCpf = FormularioPanel.campoTexto("000.000.000-00");
        campoTelefone = FormularioPanel.campoTexto("(47) 99999-9999");
        campoEmail = FormularioPanel.campoTexto("nome@email.com (opcional)");

        form.adicionarCampo("Nome:", campoNome);
        form.adicionarCampo("CPF:", campoCpf);
        form.adicionarCampo("Telefone:", campoTelefone);
        form.adicionarCampo("E-mail:", campoEmail);

        JButton botaoCancelar = new JButton("Cancelar");
        JButton botaoSalvar = new JButton("Salvar");
        botaoSalvar.setBackground(UIManager.getColor("Component.accentColor"));
        botaoSalvar.setForeground(Color.WHITE);

        if (id == null) {
            form.adicionarBotoes(botaoCancelar, botaoSalvar);
        } else {
            JButton botaoExcluir = new JButton("Excluir");
            botaoExcluir.addActionListener(e -> excluir());
            form.adicionarBotoes(botaoCancelar, botaoSalvar, botaoExcluir);
        }

        add(form, BorderLayout.CENTER);

        botaoSalvar.addActionListener(e -> salvar());
        botaoCancelar.addActionListener(e -> conteudo.mostrarTutores());
    }

    private void carregar() {
        try {
            Tutor tutor = controller.obterPeloId(id);

            campoNome.setText(tutor.getNome());
            campoCpf.setText(StringsUtil.formatarCpf(tutor.getCpf()));
            campoTelefone.setText(StringsUtil.formatarTelefone(tutor.getTelefone()));
            campoEmail.setText(tutor.getEmail());
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar o tutor. " + e.getMessage());
        }
    }

    private void salvar() {
        Tutor tutor = new Tutor();
        tutor.setId(id);
        tutor.setNome(campoNome.getText());
        tutor.setCpf(campoCpf.getText());
        tutor.setTelefone(campoTelefone.getText());
        tutor.setEmail(campoEmail.getText());

        try {
            controller.salvar(tutor);

            conteudo.mostrarTutores();
            conteudo.mensagemNormal("Tutor salvo com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro(e.getMessage());
        }
    }

    private void excluir() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este tutor?", "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resposta != JOptionPane.YES_OPTION) return;

        try {
            controller.excluir(id);

            conteudo.mostrarTutores();
            conteudo.mensagemNormal("Tutor excluído com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível excluir o tutor. " + e.getMessage());
        }
    }
}
