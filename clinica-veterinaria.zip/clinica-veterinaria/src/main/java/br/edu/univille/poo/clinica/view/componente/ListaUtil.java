package br.edu.univille.poo.clinica.view.componente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.function.Consumer;

/** Funções comuns às telas de listagem (filtros + tabela). */
public class ListaUtil {

    public static DefaultTableModel criarModelo(String[] colunas, Class<?>[] tipos) {
        return new DefaultTableModel(colunas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int column) {
                return tipos[column];
            }
        };
    }

    public static JTable criarTabela(DefaultTableModel modelo, int... larguras) {
        JTable tabela = new JTable(modelo);

        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.setRowHeight(30);
        tabela.setAutoCreateRowSorter(true);
        tabela.getTableHeader().setReorderingAllowed(false);

        for (int i = 0; i < larguras.length; i++) {
            tabela.getColumnModel().getColumn(i).setPreferredWidth(larguras[i]);
        }
        return tabela;
    }

    public static JScrollPane rolagem(JTable tabela) {
        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(new EmptyBorder(0, 10, 10, 10));
        return scroll;
    }

    /** Duplo clique em uma linha chama a ação com o ID (primeira coluna). */
    public static void aoDuploClique(JTable tabela, Consumer<Integer> acao) {
        tabela.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && SwingUtilities.isLeftMouseButton(e)) {
                    int linha = tabela.rowAtPoint(e.getPoint());
                    if (linha >= 0) {
                        acao.accept((Integer) tabela.getValueAt(linha, 0));
                    }
                }
            }
        });
    }

    public static Integer idSelecionado(JTable tabela) {
        int linha = tabela.getSelectedRow();
        return linha < 0 ? null : (Integer) tabela.getValueAt(linha, 0);
    }

    /** Filtros à esquerda e botão de cadastro à direita. */
    public static JPanel topo(JPanel filtros, JButton botaoNovo) {
        JPanel topo = new JPanel(new BorderLayout());
        topo.add(filtros, BorderLayout.WEST);

        JPanel direita = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        direita.add(botaoNovo);
        topo.add(direita, BorderLayout.EAST);

        return topo;
    }

    public static JPanel filtros() {
        return new JPanel(new FlowLayout(FlowLayout.LEFT));
    }

    public static JButton destacar(JButton botao) {
        botao.setBackground(UIManager.getColor("Component.accentColor"));
        botao.setForeground(Color.WHITE);
        return botao;
    }

}
