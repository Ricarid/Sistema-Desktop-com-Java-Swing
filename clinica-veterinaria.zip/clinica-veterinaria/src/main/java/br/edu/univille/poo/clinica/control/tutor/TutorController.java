package br.edu.univille.poo.clinica.control.tutor;

import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.usecase.PesquisarTutoresUseCase;

import java.util.List;

public class TutorController {

    private final PesquisarTutoresUseCase useCase = new PesquisarTutoresUseCase();

    public List<Tutor> pesquisar(String termo) {
        return useCase.executar(termo);
    }

}
