package br.edu.univille.poo.clinica.control.consulta;

import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.model.usecase.ExcluirConsultaUseCase;
import br.edu.univille.poo.clinica.model.usecase.ObterConsultaPeloIdUseCase;
import br.edu.univille.poo.clinica.model.usecase.PesquisarAnimaisUseCase;
import br.edu.univille.poo.clinica.model.usecase.PesquisarVeterinariosUseCase;
import br.edu.univille.poo.clinica.model.usecase.SalvarConsultaUseCase;

import java.util.List;

public class ConsultaFormController {

    private final SalvarConsultaUseCase salvarUseCase = new SalvarConsultaUseCase();
    private final ObterConsultaPeloIdUseCase obterUseCase = new ObterConsultaPeloIdUseCase();
    private final ExcluirConsultaUseCase excluirUseCase = new ExcluirConsultaUseCase();
    private final PesquisarAnimaisUseCase animaisUseCase = new PesquisarAnimaisUseCase();
    private final PesquisarVeterinariosUseCase veterinariosUseCase = new PesquisarVeterinariosUseCase();

    public void salvar(Consulta consulta) {
        salvarUseCase.executar(consulta);
    }

    public Consulta obterPeloId(Integer id) {
        return obterUseCase.executar(id);
    }

    public void excluir(Integer id) {
        excluirUseCase.executar(id);
    }

    public List<Animal> obterAnimais() {
        return animaisUseCase.executar("");
    }

    public List<Veterinario> obterVeterinariosAtivos() {
        return veterinariosUseCase.executar("", true);
    }

}
