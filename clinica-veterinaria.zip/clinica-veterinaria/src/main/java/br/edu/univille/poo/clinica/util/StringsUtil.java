package br.edu.univille.poo.clinica.util;

import java.util.Objects;

public class StringsUtil {

    public static boolean isBlank(String string){
        return Objects.isNull(string) || string.isBlank();
    }

    public static String apenasDigitos(String string){
        return Objects.isNull(string) ? "" : string.replaceAll("\\D", "");
    }

    public static String formatarCpf(String cpf){
        String d = apenasDigitos(cpf);
        if (d.length() != 11) return cpf == null ? "" : cpf;
        return d.substring(0, 3) + "." + d.substring(3, 6) + "." + d.substring(6, 9) + "-" + d.substring(9);
    }

    public static String formatarTelefone(String telefone){
        String d = apenasDigitos(telefone);
        if (d.length() == 11) return "(" + d.substring(0, 2) + ") " + d.substring(2, 7) + "-" + d.substring(7);
        if (d.length() == 10) return "(" + d.substring(0, 2) + ") " + d.substring(2, 6) + "-" + d.substring(6);
        return telefone == null ? "" : telefone;
    }

    public static boolean cpfValido(String cpf){
        String d = apenasDigitos(cpf);
        if (d.length() != 11 || d.chars().distinct().count() == 1) return false;
        return d.charAt(9) - '0' == digitoVerificador(d, 9) && d.charAt(10) - '0' == digitoVerificador(d, 10);
    }

    private static int digitoVerificador(String d, int tamanho){
        int soma = 0;
        for (int i = 0; i < tamanho; i++) {
            soma += (d.charAt(i) - '0') * (tamanho + 1 - i);
        }
        int resto = (soma * 10) % 11;
        return resto == 10 ? 0 : resto;
    }

    public static boolean emailValido(String email){
        return email.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$");
    }

}
