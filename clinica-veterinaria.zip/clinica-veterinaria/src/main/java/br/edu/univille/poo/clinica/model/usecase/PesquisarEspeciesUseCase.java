package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.EspecieDAO;
import br.edu.univille.poo.clinica.model.entity.Especie;

import java.util.List;

public class PesquisarEspeciesUseCase {

    private final EspecieDAO dao = new EspecieDAO();

    public List<Especie> executar(String nome) {
        return dao.obterTodosPeloNome(nome);
    }

}
