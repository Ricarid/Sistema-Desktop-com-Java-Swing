package br.edu.univille.poo.clinica.control.tutor;

import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.usecase.ExcluirTutorUseCase;
import br.edu.univille.poo.clinica.model.usecase.ObterTutorPeloIdUseCase;
import br.edu.univille.poo.clinica.model.usecase.SalvarTutorUseCase;

public class TutorFormController {

    private final SalvarTutorUseCase salvarUseCase = new SalvarTutorUseCase();
    private final ObterTutorPeloIdUseCase obterUseCase = new ObterTutorPeloIdUseCase();
    private final ExcluirTutorUseCase excluirUseCase = new ExcluirTutorUseCase();

    public void salvar(Tutor tutor) {
        salvarUseCase.executar(tutor);
    }

    public Tutor obterPeloId(Integer id) {
        return obterUseCase.executar(id);
    }

    public void excluir(Integer id) {
        excluirUseCase.executar(id);
    }

}
