package br.edu.univille.poo.clinica.model.database;

import br.edu.univille.poo.clinica.model.dao.ConnectionFactory;
import br.edu.univille.poo.clinica.model.exception.DaoException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import static br.edu.univille.poo.clinica.util.DataUtil.paraBanco;

/** Carrega dados de exemplo apenas quando o banco está vazio. */
public class DatabaseInitialize {

    public static void init(){
        try (var con = ConnectionFactory.getInstance().get()) {

            if (jaPossuiDados(con)) return;

            con.setAutoCommit(false);
            try {
                inserirEspecies(con);
                inserirTutores(con);
                inserirAnimais(con);
                inserirVeterinarios(con);
                inserirConsultas(con);
                con.commit();
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    private static boolean jaPossuiDados(Connection con) throws SQLException {
        try (var st = con.createStatement();
             var rs = st.executeQuery("SELECT COUNT(*) FROM especie")) {
            rs.next();
            return rs.getInt(1) > 0;
        }
    }

    private static void inserirEspecies(Connection con) throws SQLException {
        executar(con, """
            INSERT INTO especie (nome) VALUES
            ('Cão'), ('Gato'), ('Coelho'), ('Ave'), ('Hamster'), ('Réptil')
            """);
    }

    private static void inserirTutores(Connection con) throws SQLException {
        executar(con, """
            INSERT INTO tutor (nome, cpf, telefone, email) VALUES
            ('Mariana Souza',    '52998224725', '47999881122', 'mariana.souza@email.com'),
            ('Carlos Pereira',   '11144477735', '47988776655', 'carlos.pereira@email.com'),
            ('Fernanda Lima',    '12345678909', '4733221100',  NULL),
            ('Ricardo Almeida',  '39053344705', '47991234567', 'ricardo.almeida@email.com')
            """);
    }

    private static void inserirAnimais(Connection con) throws SQLException {
        executar(con, """
            INSERT INTO animal (nome, especie_id, raca, data_nascimento, peso, tutor_id) VALUES
            ('Thor',   1, 'Golden Retriever', '2020-03-15', 32.5, 1),
            ('Mia',    2, 'Siamês',           '2021-07-02',  4.1, 1),
            ('Bidu',   1, 'Vira-lata',        '2018-11-20', 12.8, 2),
            ('Pipoca', 3, 'Mini Lop',         '2023-01-10',  1.9, 3),
            ('Loro',   4, 'Papagaio',         '2016-05-05',  0.4, 4),
            ('Luna',   2, 'Persa',            '2022-09-30',  3.7, 2)
            """);
    }

    private static void inserirVeterinarios(Connection con) throws SQLException {
        executar(con, """
            INSERT INTO veterinario (nome, crmv, especialidade, ativo) VALUES
            ('Dra. Helena Martins', 'SC-10234', 'Clínica geral',        1),
            ('Dr. Paulo Nogueira',  'SC-20871', 'Cirurgia',             1),
            ('Dra. Beatriz Rocha',  'SC-31590', 'Animais silvestres',   1),
            ('Dr. Otávio Brandão',  'SC-04412', 'Dermatologia',         0)
            """);
    }

    private static void inserirConsultas(Connection con) throws SQLException {
        LocalDate hoje = LocalDate.now();

        Object[][] consultas = {
            // animal, veterinário, data/hora, motivo, diagnóstico, valor, status
            {1, 1, hoje.minusDays(20).atTime(9, 0),  "Vacinação anual",       "Vacinas em dia.",                 120.00, "REALIZADA"},
            {2, 1, hoje.minusDays(12).atTime(14, 30), "Perda de apetite",      "Gastrite leve. Dieta e medicação.", 180.00, "REALIZADA"},
            {3, 2, hoje.minusDays(5).atTime(10, 0),   "Cirurgia de castração", "Procedimento sem intercorrências.", 650.00, "REALIZADA"},
            {4, 3, hoje.minusDays(2).atTime(16, 0),   "Check-up",              null,                               90.00, "CANCELADA"},
            {1, 2, hoje.atTime(LocalTime.of(15, 0)),  "Retorno pós-vacina",    null,                               80.00, "AGENDADA"},
            {5, 3, hoje.plusDays(1).atTime(9, 30),    "Avaliação de penas",    null,                              150.00, "AGENDADA"},
            {6, 1, hoje.plusDays(3).atTime(11, 0),    "Vacinação",             null,                              120.00, "AGENDADA"}
        };

        String sql = """
            INSERT INTO consulta (animal_id, veterinario_id, data_hora, motivo, diagnostico, valor, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (Object[] c : consultas) {
                ps.setInt(1, (Integer) c[0]);
                ps.setInt(2, (Integer) c[1]);
                ps.setString(3, paraBanco((LocalDateTime) c[2]));
                ps.setString(4, (String) c[3]);
                ps.setString(5, (String) c[4]);
                ps.setDouble(6, (Double) c[5]);
                ps.setString(7, (String) c[6]);
                ps.executeUpdate();
            }
        }
    }

    private static void executar(Connection con, String sql) throws SQLException {
        try (var st = con.createStatement()) {
            st.execute(sql);
        }
    }

}
