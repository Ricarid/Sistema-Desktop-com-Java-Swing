package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.VeterinarioDAO;
import br.edu.univille.poo.clinica.model.entity.Veterinario;

import java.util.List;

public class PesquisarVeterinariosUseCase {

    private final VeterinarioDAO dao = new VeterinarioDAO();

    public List<Veterinario> executar(String nome, boolean somenteAtivos) {
        return dao.pesquisar(nome, somenteAtivos);
    }

}
