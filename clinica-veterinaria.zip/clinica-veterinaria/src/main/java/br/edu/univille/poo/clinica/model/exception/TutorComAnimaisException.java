package br.edu.univille.poo.clinica.model.exception;

public class TutorComAnimaisException extends RuntimeException {
    public TutorComAnimaisException() {
        super("O tutor possui animais associados.");
    }
}
