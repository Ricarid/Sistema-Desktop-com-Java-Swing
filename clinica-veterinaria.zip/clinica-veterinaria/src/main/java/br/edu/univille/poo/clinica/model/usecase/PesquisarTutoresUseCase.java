package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.TutorDAO;
import br.edu.univille.poo.clinica.model.entity.Tutor;

import java.util.List;

public class PesquisarTutoresUseCase {

    private final TutorDAO dao = new TutorDAO();

    public List<Tutor> executar(String termo) {
        return dao.pesquisar(termo);
    }

}
