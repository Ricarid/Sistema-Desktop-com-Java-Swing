package br.edu.univille.poo.clinica.model.dao;

import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.exception.DaoException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class AnimalDAO extends BaseDAO {

    private static final String SELECT = """
        SELECT
            a.id, a.nome, a.raca, a.data_nascimento, a.peso,
            e.id AS especie_id, e.nome AS especie_nome,
            t.id AS tutor_id, t.nome AS tutor_nome, t.cpf AS tutor_cpf,
            t.telefone AS tutor_telefone, t.email AS tutor_email
        FROM animal a
        JOIN especie e ON e.id = a.especie_id
        JOIN tutor t ON t.id = a.tutor_id
        """;

    private Animal mapear(ResultSet rs) throws SQLException {
        var especie = new Especie();
        especie.setId(rs.getInt("especie_id"));
        especie.setNome(rs.getString("especie_nome"));

        var tutor = new Tutor();
        tutor.setId(rs.getInt("tutor_id"));
        tutor.setNome(rs.getString("tutor_nome"));
        tutor.setCpf(rs.getString("tutor_cpf"));
        tutor.setTelefone(rs.getString("tutor_telefone"));
        tutor.setEmail(rs.getString("tutor_email"));

        var animal = new Animal();
        animal.setId(rs.getInt("id"));
        animal.setNome(rs.getString("nome"));
        animal.setRaca(rs.getString("raca"));
        animal.setEspecie(especie);
        animal.setTutor(tutor);

        String nascimento = rs.getString("data_nascimento");
        if (nascimento != null) animal.setDataNascimento(LocalDate.parse(nascimento));

        double peso = rs.getDouble("peso");
        animal.setPeso(rs.wasNull() ? null : peso);

        return animal;
    }

    public void inserir(Animal animal) {
        String sql = """
            INSERT INTO animal (nome, especie_id, raca, data_nascimento, peso, tutor_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """;

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            preencher(ps, animal);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void atualizar(Animal animal) {
        String sql = """
            UPDATE animal SET
                nome = ?, especie_id = ?, raca = ?, data_nascimento = ?, peso = ?, tutor_id = ?
            WHERE id = ?
            """;

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            preencher(ps, animal);
            ps.setInt(7, animal.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    private void preencher(java.sql.PreparedStatement ps, Animal animal) throws SQLException {
        ps.setString(1, animal.getNome());
        ps.setInt(2, animal.getEspecie().getId());
        ps.setString(3, animal.getRaca());

        if (animal.getDataNascimento() != null) {
            ps.setString(4, animal.getDataNascimento().toString());
        } else {
            ps.setNull(4, Types.VARCHAR);
        }

        if (animal.getPeso() != null) {
            ps.setDouble(5, animal.getPeso());
        } else {
            ps.setNull(5, Types.REAL);
        }

        ps.setInt(6, animal.getTutor().getId());
    }

    public void excluir(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement("DELETE FROM animal WHERE id = ?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public Optional<Animal> obterPeloId(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE a.id = ?")) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    /** Pesquisa pelo nome do animal ou pelo nome do tutor. */
    public List<Animal> pesquisar(String termo) {
        var lista = new ArrayList<Animal>();

        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE a.nome LIKE ? OR t.nome LIKE ? ORDER BY a.nome")) {

            ps.setString(1, like(termo));
            ps.setString(2, like(termo));

            try (var rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return lista;
    }

    public boolean existePorEspecie(Integer especieId) {
        return existe("SELECT COUNT(*) FROM animal WHERE especie_id = ?", especieId);
    }

    public boolean existePorTutor(Integer tutorId) {
        return existe("SELECT COUNT(*) FROM animal WHERE tutor_id = ?", tutorId);
    }

    private boolean existe(String sql, Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public int contar() {
        try (var con = connection();
             var ps = con.prepareStatement("SELECT COUNT(*) FROM animal");
             var rs = ps.executeQuery()) {

            rs.next();
            return rs.getInt(1);

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

}
