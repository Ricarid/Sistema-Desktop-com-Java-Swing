package br.edu.univille.poo.clinica.view.principal;

import com.formdev.flatlaf.extras.FlatSVGIcon;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class MenuLateral extends JPanel {

    private final List<MenuItem> itens = new ArrayList<>();

    public MenuLateral(ConteudoPanel conteudo) {
        setPreferredSize(new Dimension(230, 0));
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, UIManager.getColor("Component.borderColor")));

        JPanel opcoes = new JPanel();
        opcoes.setLayout(new BoxLayout(opcoes, BoxLayout.Y_AXIS));

        JLabel marca = new JLabel("Clínica Vet");
        marca.setFont(marca.getFont().deriveFont(Font.BOLD, 18f));
        marca.setForeground(UIManager.getColor("Component.accentColor"));
        marca.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 10));
        marca.setAlignmentX(Component.LEFT_ALIGNMENT);
        opcoes.add(marca);

        MenuItem inicio = criarItem("Início", "icons/inicio.svg", opcoes, conteudo::mostrarInicio);
        criarItem("Consultas", "icons/consulta.svg", opcoes, conteudo::mostrarConsultas);
        criarItem("Animais", "icons/animal.svg", opcoes, conteudo::mostrarAnimais);
        criarItem("Tutores", "icons/tutor.svg", opcoes, conteudo::mostrarTutores);
        criarItem("Veterinários", "icons/veterinario.svg", opcoes, conteudo::mostrarVeterinarios);
        criarItem("Espécies", "icons/especie.svg", opcoes, conteudo::mostrarEspecies);

        add(opcoes, BorderLayout.NORTH);

        JPanel inferior = new JPanel(new BorderLayout());
        MenuItem sair = new MenuItem(new FlatSVGIcon("icons/sair.svg", 20, 20), "Sair");
        sair.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                System.exit(0);
            }
        });
        inferior.add(sair, BorderLayout.CENTER);
        add(inferior, BorderLayout.SOUTH);

        // Tela inicial
        selecionar(inicio);
        conteudo.mostrarInicio();
    }

    private MenuItem criarItem(String texto, String icone, JPanel destino, Runnable acao) {
        MenuItem item = new MenuItem(new FlatSVGIcon(icone, 20, 20), texto);
        item.setAlignmentX(Component.LEFT_ALIGNMENT);
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, item.getPreferredSize().height));

        item.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                selecionar(item);
                acao.run();
            }
        });

        itens.add(item);
        destino.add(item);
        return item;
    }

    private void selecionar(MenuItem selecionado) {
        for (MenuItem item : itens) {
            item.selecionar(item == selecionado);
        }
    }
}
