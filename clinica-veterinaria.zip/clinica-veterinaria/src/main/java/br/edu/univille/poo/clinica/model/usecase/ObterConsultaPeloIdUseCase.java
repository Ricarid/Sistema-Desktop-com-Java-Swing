package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.exception.RegistroNaoEncontradoException;

public class ObterConsultaPeloIdUseCase {

    private final ConsultaDAO dao = new ConsultaDAO();

    public Consulta executar(Integer id) {
        return dao.obterPeloId(id).orElseThrow(() -> new RegistroNaoEncontradoException("Consulta"));
    }

}
