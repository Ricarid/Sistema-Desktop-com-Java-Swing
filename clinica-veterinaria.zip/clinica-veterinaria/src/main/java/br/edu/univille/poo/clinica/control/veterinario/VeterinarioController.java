package br.edu.univille.poo.clinica.control.veterinario;

import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.model.usecase.PesquisarVeterinariosUseCase;

import java.util.List;

public class VeterinarioController {

    private final PesquisarVeterinariosUseCase useCase = new PesquisarVeterinariosUseCase();

    public List<Veterinario> pesquisar(String nome, boolean somenteAtivos) {
        return useCase.executar(nome, somenteAtivos);
    }

}
