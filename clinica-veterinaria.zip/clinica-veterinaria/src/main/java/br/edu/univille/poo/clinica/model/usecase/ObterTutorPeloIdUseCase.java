package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.TutorDAO;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.exception.RegistroNaoEncontradoException;

public class ObterTutorPeloIdUseCase {

    private final TutorDAO dao = new TutorDAO();

    public Tutor executar(Integer id) {
        return dao.obterPeloId(id).orElseThrow(() -> new RegistroNaoEncontradoException("Tutor"));
    }

}
