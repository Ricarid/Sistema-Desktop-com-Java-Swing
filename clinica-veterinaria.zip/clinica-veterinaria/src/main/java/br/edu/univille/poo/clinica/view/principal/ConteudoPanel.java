package br.edu.univille.poo.clinica.view.principal;

import br.edu.univille.poo.clinica.view.animal.AnimalFormView;
import br.edu.univille.poo.clinica.view.animal.AnimalView;
import br.edu.univille.poo.clinica.view.componente.BarraStatus;
import br.edu.univille.poo.clinica.view.consulta.ConsultaFormView;
import br.edu.univille.poo.clinica.view.consulta.ConsultaView;
import br.edu.univille.poo.clinica.view.especie.EspecieFormView;
import br.edu.univille.poo.clinica.view.especie.EspecieView;
import br.edu.univille.poo.clinica.view.inicio.InicioView;
import br.edu.univille.poo.clinica.view.tutor.TutorFormView;
import br.edu.univille.poo.clinica.view.tutor.TutorView;
import br.edu.univille.poo.clinica.view.veterinario.VeterinarioFormView;
import br.edu.univille.poo.clinica.view.veterinario.VeterinarioView;

import javax.swing.*;
import java.awt.*;

/** Área central da janela: mostra uma tela por vez e a barra de status. */
public class ConteudoPanel extends JPanel {

    private final BarraStatus barraStatus;

    public ConteudoPanel() {
        setLayout(new BorderLayout());

        barraStatus = new BarraStatus();
        add(barraStatus, BorderLayout.SOUTH);
    }

    private void exibir(JPanel view) {
        removeAll();

        add(view, BorderLayout.CENTER);
        add(barraStatus, BorderLayout.SOUTH);
        limparMensagem();

        revalidate();
        repaint();
    }

    public void mostrarInicio() { exibir(new InicioView(this)); }

    // Consultas
    public void mostrarConsultas() { exibir(new ConsultaView(this)); }
    public void mostrarAdicionarConsulta() { exibir(new ConsultaFormView(null, this)); }
    public void mostrarEditarConsulta(Integer id) { exibir(new ConsultaFormView(id, this)); }

    // Animais
    public void mostrarAnimais() { exibir(new AnimalView(this)); }
    public void mostrarAdicionarAnimal() { exibir(new AnimalFormView(null, this)); }
    public void mostrarEditarAnimal(Integer id) { exibir(new AnimalFormView(id, this)); }

    // Tutores
    public void mostrarTutores() { exibir(new TutorView(this)); }
    public void mostrarAdicionarTutor() { exibir(new TutorFormView(null, this)); }
    public void mostrarEditarTutor(Integer id) { exibir(new TutorFormView(id, this)); }

    // Veterinários
    public void mostrarVeterinarios() { exibir(new VeterinarioView(this)); }
    public void mostrarAdicionarVeterinario() { exibir(new VeterinarioFormView(null, this)); }
    public void mostrarEditarVeterinario(Integer id) { exibir(new VeterinarioFormView(id, this)); }

    // Espécies
    public void mostrarEspecies() { exibir(new EspecieView(this)); }
    public void mostrarAdicionarEspecie() { exibir(new EspecieFormView(null, this)); }
    public void mostrarEditarEspecie(Integer id) { exibir(new EspecieFormView(id, this)); }

    public void mensagemNormal(String mensagem) { barraStatus.mensagemNormal(mensagem); }
    public void mensagemErro(String mensagem) { barraStatus.mensagemErro(mensagem); }
    public void limparMensagem() { barraStatus.limpar(); }
}
