package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;

import java.util.List;

public class PesquisarConsultasUseCase {

    private final ConsultaDAO dao = new ConsultaDAO();

    /** Status nulo significa "todos". */
    public List<Consulta> executar(String termo, StatusConsulta status) {
        return dao.pesquisar(termo, status);
    }

}
