package br.edu.univille.poo.clinica.model.dao;

import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.model.exception.DaoException;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class VeterinarioDAO extends BaseDAO {

    private static final String SELECT = "SELECT id, nome, crmv, especialidade, ativo FROM veterinario ";

    private Veterinario mapear(ResultSet rs) throws SQLException {
        var vet = new Veterinario();
        vet.setId(rs.getInt("id"));
        vet.setNome(rs.getString("nome"));
        vet.setCrmv(rs.getString("crmv"));
        vet.setEspecialidade(rs.getString("especialidade"));
        vet.setAtivo(rs.getBoolean("ativo"));
        return vet;
    }

    public void inserir(Veterinario vet) {
        String sql = "INSERT INTO veterinario (nome, crmv, especialidade, ativo) VALUES (?, ?, ?, ?)";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, vet.getNome());
            ps.setString(2, vet.getCrmv());
            ps.setString(3, vet.getEspecialidade());
            ps.setBoolean(4, vet.isAtivo());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void atualizar(Veterinario vet) {
        String sql = "UPDATE veterinario SET nome = ?, crmv = ?, especialidade = ?, ativo = ? WHERE id = ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, vet.getNome());
            ps.setString(2, vet.getCrmv());
            ps.setString(3, vet.getEspecialidade());
            ps.setBoolean(4, vet.isAtivo());
            ps.setInt(5, vet.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void excluir(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement("DELETE FROM veterinario WHERE id = ?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public Optional<Veterinario> obterPeloId(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE id = ?")) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    public Optional<Veterinario> obterPeloCrmv(String crmv) {
        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE crmv = ?")) {

            ps.setString(1, crmv);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    public List<Veterinario> pesquisar(String nome, boolean somenteAtivos) {
        var lista = new ArrayList<Veterinario>();
        String sql = SELECT + "WHERE nome LIKE ? " + (somenteAtivos ? "AND ativo = 1 " : "") + "ORDER BY nome";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, like(nome));

            try (var rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return lista;
    }

    public int contarAtivos() {
        try (var con = connection();
             var ps = con.prepareStatement("SELECT COUNT(*) FROM veterinario WHERE ativo = 1");
             var rs = ps.executeQuery()) {

            rs.next();
            return rs.getInt(1);

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

}
