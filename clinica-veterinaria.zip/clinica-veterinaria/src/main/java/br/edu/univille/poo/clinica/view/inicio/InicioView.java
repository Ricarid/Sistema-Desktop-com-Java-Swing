package br.edu.univille.poo.clinica.view.inicio;

import br.edu.univille.poo.clinica.control.inicio.InicioController;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.Resumo;
import br.edu.univille.poo.clinica.util.DataUtil;
import br.edu.univille.poo.clinica.view.componente.ListaUtil;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

/** Tela inicial: indicadores e próximas consultas agendadas. */
public class InicioView extends JPanel {

    private final InicioController controller = new InicioController();
    private final ConteudoPanel conteudo;

    public InicioView(ConteudoPanel conteudo) {
        this.conteudo = conteudo;

        setLayout(new BorderLayout(0, 15));
        setBorder(new EmptyBorder(15, 20, 0, 20));

        JLabel titulo = new JLabel("Painel da clínica");
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 20f));

        JPanel topo = new JPanel(new BorderLayout(0, 15));
        topo.add(titulo, BorderLayout.NORTH);
        add(topo, BorderLayout.NORTH);

        try {
            topo.add(criarCartoes(controller.obterResumo()), BorderLayout.CENTER);
            add(criarProximasConsultas(), BorderLayout.CENTER);
        } catch (Exception e) {
            conteudo.mensagemErro("Erro ao carregar o painel: " + e.getMessage());
        }
    }

    private JPanel criarCartoes(Resumo resumo) {
        JPanel cartoes = new JPanel(new GridLayout(1, 0, 12, 0));

        cartoes.add(criarCartao("Consultas hoje", String.valueOf(resumo.consultasHoje())));
        cartoes.add(criarCartao("Consultas agendadas", String.valueOf(resumo.consultasAgendadas())));
        cartoes.add(criarCartao("Animais", String.valueOf(resumo.totalAnimais())));
        cartoes.add(criarCartao("Tutores", String.valueOf(resumo.totalTutores())));
        cartoes.add(criarCartao("Veterinários ativos", String.valueOf(resumo.totalVeterinarios())));
        cartoes.add(criarCartao("Faturamento (realizadas)", DataUtil.formatarMoeda(resumo.faturamento())));

        return cartoes;
    }

    private JPanel criarCartao(String rotulo, String valor) {
        JPanel cartao = new JPanel(new BorderLayout(0, 4));
        cartao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UIManager.getColor("Component.borderColor")),
                new EmptyBorder(12, 14, 12, 14)));

        JLabel labelValor = new JLabel(valor);
        labelValor.setFont(labelValor.getFont().deriveFont(Font.BOLD, 22f));
        labelValor.setForeground(UIManager.getColor("Component.accentColor"));

        JLabel labelRotulo = new JLabel(rotulo);
        labelRotulo.setForeground(UIManager.getColor("Label.disabledForeground"));

        cartao.add(labelValor, BorderLayout.CENTER);
        cartao.add(labelRotulo, BorderLayout.SOUTH);
        return cartao;
    }

    private JPanel criarProximasConsultas() {
        JPanel painel = new JPanel(new BorderLayout(0, 8));

        JLabel titulo = new JLabel("Próximas consultas agendadas");
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 14f));
        painel.add(titulo, BorderLayout.NORTH);

        DefaultTableModel modelo = ListaUtil.criarModelo(
                new String[]{"ID", "Data/hora", "Animal", "Tutor", "Veterinário", "Motivo"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class, String.class, String.class});
        JTable tabela = ListaUtil.criarTabela(modelo, 50, 140, 130, 180, 190, 260);

        for (Consulta c : controller.obterProximasConsultas(10)) {
            modelo.addRow(new Object[]{
                    c.getId(),
                    DataUtil.formatar(c.getDataHora()),
                    c.getAnimal().getNome(),
                    c.getAnimal().getTutor().getNome(),
                    c.getVeterinario().getNome(),
                    c.getMotivo()
            });
        }

        ListaUtil.aoDuploClique(tabela, conteudo::mostrarEditarConsulta);

        JScrollPane scroll = new JScrollPane(tabela);
        scroll.setBorder(new EmptyBorder(0, 0, 10, 0));
        painel.add(scroll, BorderLayout.CENTER);

        return painel;
    }
}
