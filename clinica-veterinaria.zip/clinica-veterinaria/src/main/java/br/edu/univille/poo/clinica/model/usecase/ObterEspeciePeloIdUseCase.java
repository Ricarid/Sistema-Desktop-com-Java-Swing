package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.EspecieDAO;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.exception.RegistroNaoEncontradoException;

public class ObterEspeciePeloIdUseCase {

    private final EspecieDAO dao = new EspecieDAO();

    public Especie executar(Integer id) {
        return dao.obterPeloId(id).orElseThrow(() -> new RegistroNaoEncontradoException("Espécie"));
    }

}
