package br.edu.univille.poo.clinica.view.componente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class BarraStatus extends JPanel {

    private final JLabel labelMensagem;

    public BarraStatus() {
        setLayout(new BorderLayout());

        labelMensagem = new JLabel();
        labelMensagem.setBorder(new EmptyBorder(5, 10, 5, 10));

        add(labelMensagem, BorderLayout.CENTER);

        limpar();
    }

    public void mensagemNormal(String mensagem) {
        labelMensagem.setText(mensagem);
        labelMensagem.setForeground(UIManager.getColor("Label.foreground"));
    }

    public void mensagemErro(String mensagem) {
        labelMensagem.setText(mensagem);
        labelMensagem.setForeground(new Color(0xC62828));
    }

    public void limpar() {
        labelMensagem.setText(" ");
        labelMensagem.setForeground(UIManager.getColor("Label.foreground"));
    }
}
