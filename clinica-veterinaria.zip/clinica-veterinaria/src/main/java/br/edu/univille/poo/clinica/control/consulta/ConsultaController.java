package br.edu.univille.poo.clinica.control.consulta;

import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;
import br.edu.univille.poo.clinica.model.usecase.AlterarStatusConsultaUseCase;
import br.edu.univille.poo.clinica.model.usecase.ExcluirConsultaUseCase;
import br.edu.univille.poo.clinica.model.usecase.PesquisarConsultasUseCase;

import java.util.List;

public class ConsultaController {

    private final PesquisarConsultasUseCase pesquisarUseCase = new PesquisarConsultasUseCase();
    private final AlterarStatusConsultaUseCase statusUseCase = new AlterarStatusConsultaUseCase();
    private final ExcluirConsultaUseCase excluirUseCase = new ExcluirConsultaUseCase();

    public List<Consulta> pesquisar(String termo, StatusConsulta status) {
        return pesquisarUseCase.executar(termo, status);
    }

    public void alterarStatus(Integer consultaId, StatusConsulta status) {
        statusUseCase.executar(consultaId, status);
    }

    public void excluir(Integer consultaId) {
        excluirUseCase.executar(consultaId);
    }

}
