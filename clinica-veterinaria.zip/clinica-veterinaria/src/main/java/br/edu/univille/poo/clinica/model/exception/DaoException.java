package br.edu.univille.poo.clinica.model.exception;

public class DaoException extends RuntimeException {
    public DaoException(Throwable causa) {
        super("Erro ao acessar o banco de dados: " + causa.getMessage(), causa);
    }
}
