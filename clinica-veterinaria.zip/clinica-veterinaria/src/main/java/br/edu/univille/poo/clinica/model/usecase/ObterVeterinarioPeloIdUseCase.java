package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.VeterinarioDAO;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.model.exception.RegistroNaoEncontradoException;

public class ObterVeterinarioPeloIdUseCase {

    private final VeterinarioDAO dao = new VeterinarioDAO();

    public Veterinario executar(Integer id) {
        return dao.obterPeloId(id).orElseThrow(() -> new RegistroNaoEncontradoException("Veterinário"));
    }

}
