package br.edu.univille.poo.clinica.model.dao;

import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.exception.DaoException;
import br.edu.univille.poo.clinica.util.StringsUtil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class TutorDAO extends BaseDAO {

    private static final String SELECT = "SELECT id, nome, cpf, telefone, email FROM tutor ";

    private Tutor mapear(ResultSet rs) throws SQLException {
        var tutor = new Tutor();
        tutor.setId(rs.getInt("id"));
        tutor.setNome(rs.getString("nome"));
        tutor.setCpf(rs.getString("cpf"));
        tutor.setTelefone(rs.getString("telefone"));
        tutor.setEmail(rs.getString("email"));
        return tutor;
    }

    public void inserir(Tutor tutor) {
        String sql = "INSERT INTO tutor (nome, cpf, telefone, email) VALUES (?, ?, ?, ?)";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, tutor.getNome());
            ps.setString(2, tutor.getCpf());
            ps.setString(3, tutor.getTelefone());
            ps.setString(4, tutor.getEmail());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void atualizar(Tutor tutor) {
        String sql = "UPDATE tutor SET nome = ?, cpf = ?, telefone = ?, email = ? WHERE id = ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, tutor.getNome());
            ps.setString(2, tutor.getCpf());
            ps.setString(3, tutor.getTelefone());
            ps.setString(4, tutor.getEmail());
            ps.setInt(5, tutor.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void excluir(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement("DELETE FROM tutor WHERE id = ?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public Optional<Tutor> obterPeloId(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE id = ?")) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    public Optional<Tutor> obterPeloCpf(String cpf) {
        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE cpf = ?")) {

            ps.setString(1, cpf);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    /** Pesquisa pelo nome ou pelo CPF (somente dígitos). */
    public List<Tutor> pesquisar(String termo) {
        var lista = new ArrayList<Tutor>();

        String digitos = StringsUtil.apenasDigitos(termo);

        try (var con = connection();
             var ps = con.prepareStatement(
                     SELECT + "WHERE nome LIKE ? OR (? <> '' AND cpf LIKE ?) ORDER BY nome")) {

            ps.setString(1, like(termo));
            ps.setString(2, digitos);
            ps.setString(3, like(digitos));

            try (var rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return lista;
    }

    public int contar() {
        try (var con = connection();
             var ps = con.prepareStatement("SELECT COUNT(*) FROM tutor");
             var rs = ps.executeQuery()) {

            rs.next();
            return rs.getInt(1);

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

}
