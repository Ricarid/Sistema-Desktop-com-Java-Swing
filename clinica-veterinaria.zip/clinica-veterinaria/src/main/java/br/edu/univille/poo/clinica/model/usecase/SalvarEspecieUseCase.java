package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.EspecieDAO;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.util.StringsUtil;

import java.util.Objects;

public class SalvarEspecieUseCase {

    private final EspecieDAO dao;

    public SalvarEspecieUseCase() {
        dao = new EspecieDAO();
    }

    public Especie executar(Especie especie) {
        if (StringsUtil.isBlank(especie.getNome())) {
            throw new IllegalArgumentException("O nome da espécie é obrigatório.");
        }
        especie.setNome(especie.getNome().trim());

        if (especie.getNome().length() < 2) {
            throw new IllegalArgumentException("O nome da espécie deve ter no mínimo 2 letras.");
        }

        var existente = dao.obterPeloNome(especie.getNome());
        if (existente.isPresent() && !existente.get().getId().equals(especie.getId())) {
            throw new IllegalArgumentException("Já existe uma espécie com este nome.");
        }

        if (Objects.isNull(especie.getId())) {
            dao.inserir(especie);
        } else {
            dao.atualizar(especie);
        }
        return especie;
    }

}
