package br.edu.univille.poo.clinica.control.inicio;

import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.Resumo;
import br.edu.univille.poo.clinica.model.usecase.ObterProximasConsultasUseCase;
import br.edu.univille.poo.clinica.model.usecase.ObterResumoUseCase;

import java.util.List;

public class InicioController {

    private final ObterResumoUseCase resumoUseCase;
    private final ObterProximasConsultasUseCase proximasUseCase;

    public InicioController() {
        resumoUseCase = new ObterResumoUseCase();
        proximasUseCase = new ObterProximasConsultasUseCase();
    }

    public Resumo obterResumo() {
        return resumoUseCase.executar();
    }

    public List<Consulta> obterProximasConsultas(int limite) {
        return proximasUseCase.executar(limite);
    }

}
