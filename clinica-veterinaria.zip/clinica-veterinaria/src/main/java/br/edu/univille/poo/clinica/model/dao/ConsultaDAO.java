package br.edu.univille.poo.clinica.model.dao;

import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.model.exception.DaoException;
import br.edu.univille.poo.clinica.util.DataUtil;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ConsultaDAO extends BaseDAO {

    private static final String SELECT = """
        SELECT
            c.id, c.data_hora, c.motivo, c.diagnostico, c.valor, c.status,
            a.id AS animal_id, a.nome AS animal_nome, a.raca AS animal_raca,
            e.id AS especie_id, e.nome AS especie_nome,
            t.id AS tutor_id, t.nome AS tutor_nome,
            v.id AS vet_id, v.nome AS vet_nome, v.crmv AS vet_crmv,
            v.especialidade AS vet_especialidade, v.ativo AS vet_ativo
        FROM consulta c
        JOIN animal a ON a.id = c.animal_id
        JOIN especie e ON e.id = a.especie_id
        JOIN tutor t ON t.id = a.tutor_id
        JOIN veterinario v ON v.id = c.veterinario_id
        """;

    private Consulta mapear(ResultSet rs) throws SQLException {
        var especie = new Especie();
        especie.setId(rs.getInt("especie_id"));
        especie.setNome(rs.getString("especie_nome"));

        var tutor = new Tutor();
        tutor.setId(rs.getInt("tutor_id"));
        tutor.setNome(rs.getString("tutor_nome"));

        var animal = new Animal();
        animal.setId(rs.getInt("animal_id"));
        animal.setNome(rs.getString("animal_nome"));
        animal.setRaca(rs.getString("animal_raca"));
        animal.setEspecie(especie);
        animal.setTutor(tutor);

        var vet = new Veterinario();
        vet.setId(rs.getInt("vet_id"));
        vet.setNome(rs.getString("vet_nome"));
        vet.setCrmv(rs.getString("vet_crmv"));
        vet.setEspecialidade(rs.getString("vet_especialidade"));
        vet.setAtivo(rs.getBoolean("vet_ativo"));

        var consulta = new Consulta();
        consulta.setId(rs.getInt("id"));
        consulta.setAnimal(animal);
        consulta.setVeterinario(vet);
        consulta.setDataHora(DataUtil.doBanco(rs.getString("data_hora")));
        consulta.setMotivo(rs.getString("motivo"));
        consulta.setDiagnostico(rs.getString("diagnostico"));
        consulta.setValor(BigDecimal.valueOf(rs.getDouble("valor")).setScale(2, RoundingMode.HALF_UP));
        consulta.setStatus(StatusConsulta.valueOf(rs.getString("status")));
        return consulta;
    }

    public void inserir(Consulta consulta) {
        String sql = """
            INSERT INTO consulta (animal_id, veterinario_id, data_hora, motivo, diagnostico, valor, status)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """;

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            preencher(ps, consulta);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public void atualizar(Consulta consulta) {
        String sql = """
            UPDATE consulta SET
                animal_id = ?, veterinario_id = ?, data_hora = ?, motivo = ?,
                diagnostico = ?, valor = ?, status = ?
            WHERE id = ?
            """;

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            preencher(ps, consulta);
            ps.setInt(8, consulta.getId());
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    private void preencher(PreparedStatement ps, Consulta consulta) throws SQLException {
        ps.setInt(1, consulta.getAnimal().getId());
        ps.setInt(2, consulta.getVeterinario().getId());
        ps.setString(3, DataUtil.paraBanco(consulta.getDataHora()));
        ps.setString(4, consulta.getMotivo());
        ps.setString(5, consulta.getDiagnostico());
        ps.setDouble(6, consulta.getValor().doubleValue());
        ps.setString(7, consulta.getStatus().name());
    }

    public void excluir(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement("DELETE FROM consulta WHERE id = ?")) {

            ps.setInt(1, id);
            ps.executeUpdate();

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public Optional<Consulta> obterPeloId(Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement(SELECT + "WHERE c.id = ?")) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                if (rs.next()) return Optional.of(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return Optional.empty();
    }

    /** Pesquisa por animal, tutor, veterinário ou motivo. Status nulo = todos. */
    public List<Consulta> pesquisar(String termo, StatusConsulta status) {
        var lista = new ArrayList<Consulta>();

        String sql = SELECT + """
            WHERE (a.nome LIKE ? OR t.nome LIKE ? OR v.nome LIKE ? OR c.motivo LIKE ?)
            """ + (status != null ? "AND c.status = ? " : "") + "ORDER BY c.data_hora DESC";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            for (int i = 1; i <= 4; i++) ps.setString(i, like(termo));
            if (status != null) ps.setString(5, status.name());

            try (var rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return lista;
    }

    public List<Consulta> proximasAgendadas(int limite) {
        var lista = new ArrayList<Consulta>();
        String sql = SELECT + "WHERE c.status = 'AGENDADA' AND c.data_hora >= ? ORDER BY c.data_hora LIMIT ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, DataUtil.paraBanco(LocalDate.now().atStartOfDay()));
            ps.setInt(2, limite);

            try (var rs = ps.executeQuery()) {
                while (rs.next()) lista.add(mapear(rs));
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
        return lista;
    }

    /** Verdadeiro se o veterinário já possui consulta agendada exatamente neste horário. */
    public boolean existeConflito(Integer veterinarioId, LocalDateTime dataHora, Integer ignorarId) {
        String sql = """
            SELECT COUNT(*) FROM consulta
            WHERE veterinario_id = ? AND data_hora = ? AND status = 'AGENDADA' AND id <> ?
            """;

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setInt(1, veterinarioId);
            ps.setString(2, DataUtil.paraBanco(dataHora));
            ps.setInt(3, ignorarId == null ? -1 : ignorarId);

            try (var rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public boolean existePorAnimal(Integer animalId) {
        return existe("SELECT COUNT(*) FROM consulta WHERE animal_id = ?", animalId);
    }

    public boolean existePorVeterinario(Integer veterinarioId) {
        return existe("SELECT COUNT(*) FROM consulta WHERE veterinario_id = ?", veterinarioId);
    }

    private boolean existe(String sql, Integer id) {
        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (var rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public int contarPorStatus(StatusConsulta status) {
        try (var con = connection();
             var ps = con.prepareStatement("SELECT COUNT(*) FROM consulta WHERE status = ?")) {

            ps.setString(1, status.name());

            try (var rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public int contarAgendadasDoDia(LocalDate dia) {
        String sql = "SELECT COUNT(*) FROM consulta WHERE status = 'AGENDADA' AND data_hora >= ? AND data_hora < ?";

        try (var con = connection();
             var ps = con.prepareStatement(sql)) {

            ps.setString(1, DataUtil.paraBanco(dia.atStartOfDay()));
            ps.setString(2, DataUtil.paraBanco(dia.plusDays(1).atStartOfDay()));

            try (var rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

    public BigDecimal somarValorRealizadas() {
        try (var con = connection();
             var ps = con.prepareStatement("SELECT COALESCE(SUM(valor), 0) FROM consulta WHERE status = 'REALIZADA'");
             var rs = ps.executeQuery()) {

            rs.next();
            return BigDecimal.valueOf(rs.getDouble(1)).setScale(2, RoundingMode.HALF_UP);

        } catch (SQLException e) {
            throw new DaoException(e);
        }
    }

}
