package br.edu.univille.poo.clinica.control.especie;

import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.usecase.PesquisarEspeciesUseCase;

import java.util.List;

public class EspecieController {

    private final PesquisarEspeciesUseCase useCase = new PesquisarEspeciesUseCase();

    public List<Especie> pesquisar(String nome) {
        return useCase.executar(nome);
    }

}
