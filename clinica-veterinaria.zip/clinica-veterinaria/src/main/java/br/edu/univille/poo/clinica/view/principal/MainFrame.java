package br.edu.univille.poo.clinica.view.principal;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private MenuLateral menuLateral;
    private ConteudoPanel conteudoPanel;

    public MainFrame() {
        configurarJanela();
        configurarConteudo();
        configurarMenu();
    }

    private void configurarJanela() {
        setSize(1150, 680);
        setMinimumSize(new Dimension(900, 520));
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Clínica Veterinária");
        setLocationRelativeTo(null);
    }

    private void configurarConteudo() {
        conteudoPanel = new ConteudoPanel();
        menuLateral = new MenuLateral(conteudoPanel);

        setLayout(new BorderLayout());
        add(menuLateral, BorderLayout.WEST);
        add(conteudoPanel, BorderLayout.CENTER);
    }

    private void configurarMenu() {
        JMenuBar menuBar = new JMenuBar();

        JMenu arquivo = new JMenu("Arquivo");
        arquivo.setMnemonic('a');

        JMenuItem alternarMenu = new JMenuItem("Ocultar menu lateral");
        alternarMenu.setMnemonic('O');
        alternarMenu.addActionListener(e -> {
            menuLateral.setVisible(!menuLateral.isVisible());
            alternarMenu.setText((menuLateral.isVisible() ? "Ocultar" : "Mostrar") + " menu lateral");
        });

        JMenuItem sair = new JMenuItem("Sair");
        sair.setMnemonic('S');
        sair.addActionListener(e -> System.exit(0));

        arquivo.add(alternarMenu);
        arquivo.addSeparator();
        arquivo.add(sair);

        JMenu ajuda = new JMenu("Ajuda");
        ajuda.setMnemonic('j');

        JMenuItem sobre = new JMenuItem("Sobre");
        sobre.setMnemonic('S');
        sobre.addActionListener(e -> JOptionPane.showMessageDialog(
                this,
                "Clínica Veterinária\nSistema desktop em Java Swing com padrão MVC e banco SQLite.",
                "Sobre",
                JOptionPane.INFORMATION_MESSAGE));
        ajuda.add(sobre);

        menuBar.add(arquivo);
        menuBar.add(ajuda);

        setJMenuBar(menuBar);
    }

}
