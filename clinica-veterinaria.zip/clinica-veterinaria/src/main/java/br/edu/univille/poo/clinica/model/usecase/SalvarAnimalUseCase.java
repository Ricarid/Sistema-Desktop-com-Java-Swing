package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.util.StringsUtil;

import java.time.LocalDate;
import java.util.Objects;

public class SalvarAnimalUseCase {

    private final AnimalDAO dao;

    public SalvarAnimalUseCase() {
        dao = new AnimalDAO();
    }

    public Animal executar(Animal animal) {
        if (StringsUtil.isBlank(animal.getNome())) {
            throw new IllegalArgumentException("O nome do animal é obrigatório.");
        }
        animal.setNome(animal.getNome().trim());

        if (Objects.isNull(animal.getEspecie())) {
            throw new IllegalArgumentException("Selecione a espécie do animal.");
        }
        if (Objects.isNull(animal.getTutor())) {
            throw new IllegalArgumentException("Selecione o tutor do animal.");
        }

        animal.setRaca(StringsUtil.isBlank(animal.getRaca()) ? null : animal.getRaca().trim());

        if (animal.getDataNascimento() != null && animal.getDataNascimento().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("A data de nascimento não pode estar no futuro.");
        }
        if (animal.getPeso() != null && (animal.getPeso() <= 0 || animal.getPeso() > 1000)) {
            throw new IllegalArgumentException("O peso deve ser maior que zero e menor que 1000 kg.");
        }

        if (Objects.isNull(animal.getId())) {
            dao.inserir(animal);
        } else {
            dao.atualizar(animal);
        }
        return animal;
    }

}
