package br.edu.univille.poo.clinica.view.especie;

import br.edu.univille.poo.clinica.control.especie.EspecieController;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.view.componente.ListaUtil;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class EspecieView extends JPanel {

    private final EspecieController controller = new EspecieController();
    private final ConteudoPanel conteudo;

    private JTextField campoNome;
    private DefaultTableModel modeloTabela;
    private JTable tabela;

    public EspecieView(ConteudoPanel conteudo) {
        this.conteudo = conteudo;

        configurarLayout();
        pesquisar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10));

        campoNome = new JTextField(25);
        JButton botaoPesquisar = new JButton("Pesquisar");
        JButton botaoLimpar = new JButton("Limpar");
        JButton botaoNova = ListaUtil.destacar(new JButton("Nova espécie"));

        JPanel filtros = ListaUtil.filtros();
        filtros.add(new JLabel("Nome:"));
        filtros.add(campoNome);
        filtros.add(botaoPesquisar);
        filtros.add(botaoLimpar);

        add(ListaUtil.topo(filtros, botaoNova), BorderLayout.NORTH);

        modeloTabela = ListaUtil.criarModelo(
                new String[]{"ID", "Nome"},
                new Class<?>[]{Integer.class, String.class});
        tabela = ListaUtil.criarTabela(modeloTabela, 60, 500);

        add(ListaUtil.rolagem(tabela), BorderLayout.CENTER);

        ListaUtil.aoDuploClique(tabela, conteudo::mostrarEditarEspecie);

        campoNome.addActionListener(e -> pesquisar());
        botaoPesquisar.addActionListener(e -> pesquisar());
        botaoLimpar.addActionListener(e -> {
            campoNome.setText("");
            pesquisar();
        });
        botaoNova.addActionListener(e -> conteudo.mostrarAdicionarEspecie());
    }

    private void pesquisar() {
        try {
            modeloTabela.setRowCount(0);

            for (Especie especie : controller.pesquisar(campoNome.getText().trim())) {
                modeloTabela.addRow(new Object[]{especie.getId(), especie.getNome()});
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Erro ao pesquisar espécies: " + e.getMessage());
        }
    }
}
