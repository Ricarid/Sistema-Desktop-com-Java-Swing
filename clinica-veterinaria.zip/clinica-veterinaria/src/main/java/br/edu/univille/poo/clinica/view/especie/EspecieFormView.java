package br.edu.univille.poo.clinica.view.especie;

import br.edu.univille.poo.clinica.control.especie.EspecieFormController;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.view.componente.FormularioPanel;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import java.awt.*;

/** Serve para cadastrar (id nulo) e para editar (id informado). */
public class EspecieFormView extends JPanel {

    private final EspecieFormController controller = new EspecieFormController();
    private final ConteudoPanel conteudo;
    private final Integer id;

    private JTextField campoNome;

    public EspecieFormView(Integer id, ConteudoPanel conteudo) {
        this.id = id;
        this.conteudo = conteudo;

        configurarLayout();
        if (id != null) carregar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout());

        FormularioPanel form = new FormularioPanel(id == null ? "Nova espécie" : "Editar espécie");

        campoNome = FormularioPanel.campoTexto("Ex.: Cão, Gato, Ave");
        form.adicionarCampo("Nome:", campoNome);

        JButton botaoCancelar = new JButton("Cancelar");
        JButton botaoSalvar = new JButton("Salvar");
        botaoSalvar.setBackground(UIManager.getColor("Component.accentColor"));
        botaoSalvar.setForeground(Color.WHITE);

        if (id == null) {
            form.adicionarBotoes(botaoCancelar, botaoSalvar);
        } else {
            JButton botaoExcluir = new JButton("Excluir");
            botaoExcluir.addActionListener(e -> excluir());
            form.adicionarBotoes(botaoCancelar, botaoSalvar, botaoExcluir);
        }

        add(form, BorderLayout.CENTER);

        botaoSalvar.addActionListener(e -> salvar());
        botaoCancelar.addActionListener(e -> conteudo.mostrarEspecies());
        campoNome.addActionListener(e -> salvar());
    }

    private void carregar() {
        try {
            campoNome.setText(controller.obterPeloId(id).getNome());
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar a espécie. " + e.getMessage());
        }
    }

    private void salvar() {
        Especie especie = new Especie();
        especie.setId(id);
        especie.setNome(campoNome.getText());

        try {
            controller.salvar(especie);

            conteudo.mostrarEspecies();
            conteudo.mensagemNormal("Espécie salva com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro(e.getMessage());
        }
    }

    private void excluir() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir esta espécie?", "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resposta != JOptionPane.YES_OPTION) return;

        try {
            controller.excluir(id);

            conteudo.mostrarEspecies();
            conteudo.mensagemNormal("Espécie excluída com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível excluir a espécie. " + e.getMessage());
        }
    }
}
