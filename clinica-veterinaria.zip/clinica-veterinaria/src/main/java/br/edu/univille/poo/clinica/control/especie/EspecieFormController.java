package br.edu.univille.poo.clinica.control.especie;

import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.usecase.ExcluirEspecieUseCase;
import br.edu.univille.poo.clinica.model.usecase.ObterEspeciePeloIdUseCase;
import br.edu.univille.poo.clinica.model.usecase.SalvarEspecieUseCase;

public class EspecieFormController {

    private final SalvarEspecieUseCase salvarUseCase = new SalvarEspecieUseCase();
    private final ObterEspeciePeloIdUseCase obterUseCase = new ObterEspeciePeloIdUseCase();
    private final ExcluirEspecieUseCase excluirUseCase = new ExcluirEspecieUseCase();

    public void salvar(Especie especie) {
        salvarUseCase.executar(especie);
    }

    public Especie obterPeloId(Integer id) {
        return obterUseCase.executar(id);
    }

    public void excluir(Integer id) {
        excluirUseCase.executar(id);
    }

}
