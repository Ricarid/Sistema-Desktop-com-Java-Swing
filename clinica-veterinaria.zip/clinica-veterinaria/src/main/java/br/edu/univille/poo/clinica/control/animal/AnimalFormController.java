package br.edu.univille.poo.clinica.control.animal;

import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.model.usecase.ExcluirAnimalUseCase;
import br.edu.univille.poo.clinica.model.usecase.ObterAnimalPeloIdUseCase;
import br.edu.univille.poo.clinica.model.usecase.PesquisarEspeciesUseCase;
import br.edu.univille.poo.clinica.model.usecase.PesquisarTutoresUseCase;
import br.edu.univille.poo.clinica.model.usecase.SalvarAnimalUseCase;

import java.util.List;

public class AnimalFormController {

    private final SalvarAnimalUseCase salvarUseCase = new SalvarAnimalUseCase();
    private final ObterAnimalPeloIdUseCase obterUseCase = new ObterAnimalPeloIdUseCase();
    private final ExcluirAnimalUseCase excluirUseCase = new ExcluirAnimalUseCase();
    private final PesquisarEspeciesUseCase especiesUseCase = new PesquisarEspeciesUseCase();
    private final PesquisarTutoresUseCase tutoresUseCase = new PesquisarTutoresUseCase();

    public void salvar(Animal animal) {
        salvarUseCase.executar(animal);
    }

    public Animal obterPeloId(Integer id) {
        return obterUseCase.executar(id);
    }

    public void excluir(Integer id) {
        excluirUseCase.executar(id);
    }

    public List<Especie> obterEspecies() {
        return especiesUseCase.executar("");
    }

    public List<Tutor> obterTutores() {
        return tutoresUseCase.executar("");
    }

}
