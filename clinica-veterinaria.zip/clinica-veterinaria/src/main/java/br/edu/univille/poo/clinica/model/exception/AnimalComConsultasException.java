package br.edu.univille.poo.clinica.model.exception;

public class AnimalComConsultasException extends RuntimeException {
    public AnimalComConsultasException() {
        super("O animal possui consultas associadas.");
    }
}
