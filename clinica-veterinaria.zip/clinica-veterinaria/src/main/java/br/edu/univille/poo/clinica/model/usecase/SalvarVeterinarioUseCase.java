package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.VeterinarioDAO;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.util.StringsUtil;

import java.util.Objects;

public class SalvarVeterinarioUseCase {

    private final VeterinarioDAO dao;

    public SalvarVeterinarioUseCase() {
        dao = new VeterinarioDAO();
    }

    public Veterinario executar(Veterinario vet) {
        if (StringsUtil.isBlank(vet.getNome())) {
            throw new IllegalArgumentException("O nome do veterinário é obrigatório.");
        }
        vet.setNome(vet.getNome().trim());

        if (vet.getNome().length() < 3) {
            throw new IllegalArgumentException("O nome do veterinário deve ter no mínimo 3 letras.");
        }

        if (StringsUtil.isBlank(vet.getCrmv())) {
            throw new IllegalArgumentException("O CRMV é obrigatório.");
        }
        vet.setCrmv(vet.getCrmv().trim().toUpperCase());

        if (vet.getCrmv().length() < 4) {
            throw new IllegalArgumentException("CRMV inválido. Exemplo: SC-12345.");
        }

        vet.setEspecialidade(StringsUtil.isBlank(vet.getEspecialidade()) ? null : vet.getEspecialidade().trim());

        var existente = dao.obterPeloCrmv(vet.getCrmv());
        if (existente.isPresent() && !existente.get().getId().equals(vet.getId())) {
            throw new IllegalArgumentException("Já existe um veterinário com este CRMV.");
        }

        if (Objects.isNull(vet.getId())) {
            dao.inserir(vet);
        } else {
            dao.atualizar(vet);
        }
        return vet;
    }

}
