package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;
import br.edu.univille.poo.clinica.util.StringsUtil;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

public class SalvarConsultaUseCase {

    private final ConsultaDAO dao;

    public SalvarConsultaUseCase() {
        dao = new ConsultaDAO();
    }

    public Consulta executar(Consulta consulta) {
        if (Objects.isNull(consulta.getAnimal())) {
            throw new IllegalArgumentException("Selecione o animal.");
        }
        if (Objects.isNull(consulta.getVeterinario())) {
            throw new IllegalArgumentException("Selecione o veterinário.");
        }
        if (Objects.isNull(consulta.getDataHora())) {
            throw new IllegalArgumentException("Informe a data e a hora da consulta.");
        }
        if (Objects.isNull(consulta.getStatus())) {
            throw new IllegalArgumentException("Selecione o status da consulta.");
        }

        if (StringsUtil.isBlank(consulta.getMotivo()) || consulta.getMotivo().trim().length() < 3) {
            throw new IllegalArgumentException("Informe o motivo da consulta (mínimo 3 letras).");
        }
        consulta.setMotivo(consulta.getMotivo().trim());

        consulta.setDiagnostico(
                StringsUtil.isBlank(consulta.getDiagnostico()) ? null : consulta.getDiagnostico().trim());

        if (Objects.isNull(consulta.getValor()) || consulta.getValor().compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("O valor da consulta não pode ser negativo.");
        }

        if (consulta.getStatus() == StatusConsulta.AGENDADA) {
            if (!consulta.getVeterinario().isAtivo()) {
                throw new IllegalArgumentException("O veterinário selecionado está inativo.");
            }
            if (dao.existeConflito(consulta.getVeterinario().getId(), consulta.getDataHora(), consulta.getId())) {
                throw new IllegalArgumentException("O veterinário já possui uma consulta agendada neste horário.");
            }
        }

        if (consulta.getStatus() == StatusConsulta.REALIZADA
                && consulta.getDataHora().toLocalDate().isAfter(LocalDate.now())) {
            throw new IllegalArgumentException("Uma consulta futura não pode ser marcada como realizada.");
        }

        if (Objects.isNull(consulta.getId())) {
            dao.inserir(consulta);
        } else {
            dao.atualizar(consulta);
        }
        return consulta;
    }

}
