package br.edu.univille.poo.clinica.view.consulta;

import br.edu.univille.poo.clinica.control.consulta.ConsultaController;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;
import br.edu.univille.poo.clinica.util.DataUtil;
import br.edu.univille.poo.clinica.view.componente.ListaUtil;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ConsultaView extends JPanel {

    private static final String TODOS = "Todos";

    private final ConsultaController controller = new ConsultaController();
    private final ConteudoPanel conteudo;

    private JTextField campoBusca;
    private JComboBox<Object> comboStatus;
    private DefaultTableModel modeloTabela;
    private JTable tabela;

    public ConsultaView(ConteudoPanel conteudo) {
        this.conteudo = conteudo;

        configurarLayout();
        pesquisar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10));

        campoBusca = new JTextField(22);
        campoBusca.putClientProperty("JTextField.placeholderText", "Animal, tutor, veterinário ou motivo");

        comboStatus = new JComboBox<>();
        comboStatus.addItem(TODOS);
        for (StatusConsulta status : StatusConsulta.values()) comboStatus.addItem(status);

        JButton botaoPesquisar = new JButton("Pesquisar");
        JButton botaoLimpar = new JButton("Limpar");
        JButton botaoNova = ListaUtil.destacar(new JButton("Nova consulta"));

        JPanel filtros = ListaUtil.filtros();
        filtros.add(new JLabel("Buscar:"));
        filtros.add(campoBusca);
        filtros.add(new JLabel("Status:"));
        filtros.add(comboStatus);
        filtros.add(botaoPesquisar);
        filtros.add(botaoLimpar);

        add(ListaUtil.topo(filtros, botaoNova), BorderLayout.NORTH);

        modeloTabela = ListaUtil.criarModelo(
                new String[]{"ID", "Data/hora", "Animal", "Tutor", "Veterinário", "Motivo", "Valor", "Status"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class,
                        String.class, String.class, String.class, String.class});
        tabela = ListaUtil.criarTabela(modeloTabela, 50, 130, 110, 150, 160, 200, 90, 90);

        // Ações sobre a consulta selecionada
        JButton botaoConcluir = new JButton("Marcar como realizada");
        JButton botaoCancelarConsulta = new JButton("Cancelar consulta");
        JButton botaoEditar = new JButton("Editar");
        JButton botaoExcluir = new JButton("Excluir");

        JPanel acoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        acoes.setBorder(new EmptyBorder(0, 10, 10, 10));
        acoes.add(new JLabel("Selecionada:"));
        acoes.add(botaoConcluir);
        acoes.add(botaoCancelarConsulta);
        acoes.add(botaoEditar);
        acoes.add(botaoExcluir);

        add(ListaUtil.rolagem(tabela), BorderLayout.CENTER);
        add(acoes, BorderLayout.SOUTH);

        ListaUtil.aoDuploClique(tabela, conteudo::mostrarEditarConsulta);

        campoBusca.addActionListener(e -> pesquisar());
        comboStatus.addActionListener(e -> pesquisar());
        botaoPesquisar.addActionListener(e -> pesquisar());
        botaoLimpar.addActionListener(e -> {
            campoBusca.setText("");
            comboStatus.setSelectedIndex(0);
            pesquisar();
        });
        botaoNova.addActionListener(e -> conteudo.mostrarAdicionarConsulta());

        botaoConcluir.addActionListener(e -> alterarStatus(StatusConsulta.REALIZADA));
        botaoCancelarConsulta.addActionListener(e -> alterarStatus(StatusConsulta.CANCELADA));
        botaoEditar.addActionListener(e -> {
            Integer id = selecionada();
            if (id != null) conteudo.mostrarEditarConsulta(id);
        });
        botaoExcluir.addActionListener(e -> excluir());
    }

    private Integer selecionada() {
        Integer id = ListaUtil.idSelecionado(tabela);
        if (id == null) conteudo.mensagemErro("Selecione uma consulta na tabela.");
        return id;
    }

    private void pesquisar() {
        try {
            StatusConsulta status = comboStatus.getSelectedItem() instanceof StatusConsulta s ? s : null;

            modeloTabela.setRowCount(0);

            for (Consulta c : controller.pesquisar(campoBusca.getText().trim(), status)) {
                modeloTabela.addRow(new Object[]{
                        c.getId(),
                        DataUtil.formatar(c.getDataHora()),
                        c.getAnimal().getNome(),
                        c.getAnimal().getTutor().getNome(),
                        c.getVeterinario().getNome(),
                        c.getMotivo(),
                        DataUtil.formatarMoeda(c.getValor()),
                        c.getStatus().getDescricao()
                });
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Erro ao pesquisar consultas: " + e.getMessage());
        }
    }

    private void alterarStatus(StatusConsulta novoStatus) {
        Integer id = selecionada();
        if (id == null) return;

        try {
            controller.alterarStatus(id, novoStatus);

            pesquisar();
            conteudo.mensagemNormal("Consulta marcada como " + novoStatus.getDescricao().toLowerCase() + ".");
        } catch (Exception e) {
            conteudo.mensagemErro(e.getMessage());
        }
    }

    private void excluir() {
        Integer id = selecionada();
        if (id == null) return;

        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir esta consulta?", "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resposta != JOptionPane.YES_OPTION) return;

        try {
            controller.excluir(id);

            pesquisar();
            conteudo.mensagemNormal("Consulta excluída com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível excluir a consulta. " + e.getMessage());
        }
    }
}
