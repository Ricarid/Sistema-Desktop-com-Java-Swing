package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.dao.TutorDAO;
import br.edu.univille.poo.clinica.model.exception.TutorComAnimaisException;

public class ExcluirTutorUseCase {

    private final TutorDAO dao;
    private final AnimalDAO animalDAO;

    public ExcluirTutorUseCase() {
        dao = new TutorDAO();
        animalDAO = new AnimalDAO();
    }

    public void executar(Integer tutorId) {
        if (animalDAO.existePorTutor(tutorId)) {
            throw new TutorComAnimaisException();
        }
        dao.excluir(tutorId);
    }

}
