package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.dao.VeterinarioDAO;
import br.edu.univille.poo.clinica.model.exception.VeterinarioComConsultasException;

public class ExcluirVeterinarioUseCase {

    private final VeterinarioDAO dao;
    private final ConsultaDAO consultaDAO;

    public ExcluirVeterinarioUseCase() {
        dao = new VeterinarioDAO();
        consultaDAO = new ConsultaDAO();
    }

    public void executar(Integer veterinarioId) {
        if (consultaDAO.existePorVeterinario(veterinarioId)) {
            throw new VeterinarioComConsultasException();
        }
        dao.excluir(veterinarioId);
    }

}
