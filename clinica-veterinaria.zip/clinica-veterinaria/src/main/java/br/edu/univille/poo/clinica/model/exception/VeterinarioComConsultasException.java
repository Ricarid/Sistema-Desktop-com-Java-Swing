package br.edu.univille.poo.clinica.model.exception;

public class VeterinarioComConsultasException extends RuntimeException {
    public VeterinarioComConsultasException() {
        super("O veterinário possui consultas associadas.");
    }
}
