package br.edu.univille.poo.clinica;

import br.edu.univille.poo.clinica.model.database.DatabaseCreator;
import br.edu.univille.poo.clinica.model.database.DatabaseInitialize;
import br.edu.univille.poo.clinica.view.principal.MainFrame;
import com.formdev.flatlaf.FlatLaf;
import com.formdev.flatlaf.FlatLightLaf;

import javax.swing.*;
import java.util.Map;

public class App {

    public static void main(String[] args) {
        DatabaseCreator.create();
        DatabaseInitialize.init();

        SwingUtilities.invokeLater(() -> {
            FlatLaf.setGlobalExtraDefaults(Map.of("@accentColor", "#0E8F7E"));
            FlatLightLaf.setup();
            UIManager.put("Component.arc", 10);
            UIManager.put("Button.arc", 10);
            UIManager.put("TextComponent.arc", 10);

            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

}
