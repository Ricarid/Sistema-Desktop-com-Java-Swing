package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.TutorDAO;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.util.StringsUtil;

import java.util.Objects;

public class SalvarTutorUseCase {

    private final TutorDAO dao;

    public SalvarTutorUseCase() {
        dao = new TutorDAO();
    }

    public Tutor executar(Tutor tutor) {
        if (StringsUtil.isBlank(tutor.getNome())) {
            throw new IllegalArgumentException("O nome do tutor é obrigatório.");
        }
        tutor.setNome(tutor.getNome().trim());

        if (tutor.getNome().length() < 3) {
            throw new IllegalArgumentException("O nome do tutor deve ter no mínimo 3 letras.");
        }

        if (!StringsUtil.cpfValido(tutor.getCpf())) {
            throw new IllegalArgumentException("CPF inválido.");
        }
        tutor.setCpf(StringsUtil.apenasDigitos(tutor.getCpf()));

        String telefone = StringsUtil.apenasDigitos(tutor.getTelefone());
        if (telefone.length() < 10 || telefone.length() > 11) {
            throw new IllegalArgumentException("Telefone inválido. Informe o DDD e o número.");
        }
        tutor.setTelefone(telefone);

        if (StringsUtil.isBlank(tutor.getEmail())) {
            tutor.setEmail(null);
        } else {
            tutor.setEmail(tutor.getEmail().trim());
            if (!StringsUtil.emailValido(tutor.getEmail())) {
                throw new IllegalArgumentException("E-mail inválido.");
            }
        }

        var existente = dao.obterPeloCpf(tutor.getCpf());
        if (existente.isPresent() && !existente.get().getId().equals(tutor.getId())) {
            throw new IllegalArgumentException("Já existe um tutor cadastrado com este CPF.");
        }

        if (Objects.isNull(tutor.getId())) {
            dao.inserir(tutor);
        } else {
            dao.atualizar(tutor);
        }
        return tutor;
    }

}
