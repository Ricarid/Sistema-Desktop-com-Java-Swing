package br.edu.univille.poo.clinica.model.entity;

import java.math.BigDecimal;

public record Resumo(
        int totalTutores,
        int totalAnimais,
        int totalVeterinarios,
        int consultasAgendadas,
        int consultasHoje,
        BigDecimal faturamento
) {}
