package br.edu.univille.poo.clinica.control.animal;

import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.usecase.PesquisarAnimaisUseCase;

import java.util.List;

public class AnimalController {

    private final PesquisarAnimaisUseCase useCase = new PesquisarAnimaisUseCase();

    public List<Animal> pesquisar(String termo) {
        return useCase.executar(termo);
    }

}
