package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.AnimalDAO;
import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.exception.RegistroNaoEncontradoException;

public class ObterAnimalPeloIdUseCase {

    private final AnimalDAO dao = new AnimalDAO();

    public Animal executar(Integer id) {
        return dao.obterPeloId(id).orElseThrow(() -> new RegistroNaoEncontradoException("Animal"));
    }

}
