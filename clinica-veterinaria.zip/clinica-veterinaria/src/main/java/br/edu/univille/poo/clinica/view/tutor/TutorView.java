package br.edu.univille.poo.clinica.view.tutor;

import br.edu.univille.poo.clinica.control.tutor.TutorController;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.util.StringsUtil;
import br.edu.univille.poo.clinica.view.componente.ListaUtil;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class TutorView extends JPanel {

    private final TutorController controller = new TutorController();
    private final ConteudoPanel conteudo;

    private JTextField campoBusca;
    private DefaultTableModel modeloTabela;
    private JTable tabela;

    public TutorView(ConteudoPanel conteudo) {
        this.conteudo = conteudo;

        configurarLayout();
        pesquisar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout(10, 10));

        campoBusca = new JTextField(25);
        campoBusca.putClientProperty("JTextField.placeholderText", "Nome ou CPF");
        JButton botaoPesquisar = new JButton("Pesquisar");
        JButton botaoLimpar = new JButton("Limpar");
        JButton botaoNovo = ListaUtil.destacar(new JButton("Novo tutor"));

        JPanel filtros = ListaUtil.filtros();
        filtros.add(new JLabel("Buscar:"));
        filtros.add(campoBusca);
        filtros.add(botaoPesquisar);
        filtros.add(botaoLimpar);

        add(ListaUtil.topo(filtros, botaoNovo), BorderLayout.NORTH);

        modeloTabela = ListaUtil.criarModelo(
                new String[]{"ID", "Nome", "CPF", "Telefone", "E-mail"},
                new Class<?>[]{Integer.class, String.class, String.class, String.class, String.class});
        tabela = ListaUtil.criarTabela(modeloTabela, 60, 300, 130, 130, 250);

        add(ListaUtil.rolagem(tabela), BorderLayout.CENTER);

        ListaUtil.aoDuploClique(tabela, conteudo::mostrarEditarTutor);

        campoBusca.addActionListener(e -> pesquisar());
        botaoPesquisar.addActionListener(e -> pesquisar());
        botaoLimpar.addActionListener(e -> {
            campoBusca.setText("");
            pesquisar();
        });
        botaoNovo.addActionListener(e -> conteudo.mostrarAdicionarTutor());
    }

    private void pesquisar() {
        try {
            modeloTabela.setRowCount(0);

            for (Tutor tutor : controller.pesquisar(campoBusca.getText().trim())) {
                modeloTabela.addRow(new Object[]{
                        tutor.getId(),
                        tutor.getNome(),
                        StringsUtil.formatarCpf(tutor.getCpf()),
                        StringsUtil.formatarTelefone(tutor.getTelefone()),
                        tutor.getEmail() == null ? "" : tutor.getEmail()
                });
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Erro ao pesquisar tutores: " + e.getMessage());
        }
    }
}
