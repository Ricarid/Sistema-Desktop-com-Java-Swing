package br.edu.univille.poo.clinica.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.Locale;
import java.text.NumberFormat;

public class DataUtil {

    private static final DateTimeFormatter DATA =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter DATA_HORA =
            DateTimeFormatter.ofPattern("dd/MM/uuuu HH:mm").withResolverStyle(ResolverStyle.STRICT);
    private static final DateTimeFormatter BANCO_DATA_HORA =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private static final Locale PT_BR = Locale.forLanguageTag("pt-BR");

    // ---------- tela ----------
    public static String formatar(LocalDate data){
        return data == null ? "" : data.format(DATA);
    }

    public static String formatar(LocalDateTime dataHora){
        return dataHora == null ? "" : dataHora.format(DATA_HORA);
    }

    public static String formatarMoeda(BigDecimal valor){
        return NumberFormat.getCurrencyInstance(PT_BR).format(valor == null ? BigDecimal.ZERO : valor);
    }

    /** Retorna null quando o texto está vazio; lança IllegalArgumentException quando inválido. */
    public static LocalDate lerData(String texto){
        if (StringsUtil.isBlank(texto)) return null;
        try {
            return LocalDate.parse(texto.trim(), DATA);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Data inválida. Use o formato dd/mm/aaaa.");
        }
    }

    public static LocalDateTime lerDataHora(String texto){
        if (StringsUtil.isBlank(texto)) return null;
        try {
            return LocalDateTime.parse(texto.trim(), DATA_HORA);
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Data/hora inválida. Use o formato dd/mm/aaaa hh:mm.");
        }
    }

    /** Aceita 150,50 / 150.50 / 1.250,00. Vazio vira zero. */
    public static BigDecimal lerValor(String texto){
        if (StringsUtil.isBlank(texto)) return BigDecimal.ZERO;
        String t = texto.trim().replace("R$", "").trim();
        if (t.contains(",")) {
            t = t.replace(".", "").replace(",", ".");
        }
        try {
            return new BigDecimal(t).setScale(2, RoundingMode.HALF_UP);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Valor inválido.");
        }
    }

    public static Double lerPeso(String texto){
        if (StringsUtil.isBlank(texto)) return null;
        try {
            return Double.valueOf(texto.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Peso inválido.");
        }
    }

    // ---------- banco ----------
    public static String paraBanco(LocalDateTime dataHora){
        return dataHora.format(BANCO_DATA_HORA);
    }

    public static LocalDateTime doBanco(String texto){
        return texto == null ? null : LocalDateTime.parse(texto, BANCO_DATA_HORA);
    }

}
