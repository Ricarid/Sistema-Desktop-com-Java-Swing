package br.edu.univille.poo.clinica.view.animal;

import br.edu.univille.poo.clinica.control.animal.AnimalFormController;
import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.entity.Especie;
import br.edu.univille.poo.clinica.model.entity.Tutor;
import br.edu.univille.poo.clinica.util.DataUtil;
import br.edu.univille.poo.clinica.util.StringsUtil;
import br.edu.univille.poo.clinica.view.componente.FormularioPanel;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import java.awt.*;

public class AnimalFormView extends JPanel {

    private final AnimalFormController controller = new AnimalFormController();
    private final ConteudoPanel conteudo;
    private final Integer id;

    private JTextField campoNome;
    private JComboBox<Especie> comboEspecie;
    private JTextField campoRaca;
    private JTextField campoNascimento;
    private JTextField campoPeso;
    private JComboBox<Tutor> comboTutor;

    public AnimalFormView(Integer id, ConteudoPanel conteudo) {
        this.id = id;
        this.conteudo = conteudo;

        configurarLayout();
        carregarCombos();
        if (id != null) carregar();
    }

    private void configurarLayout() {
        setLayout(new BorderLayout());

        FormularioPanel form = new FormularioPanel(id == null ? "Novo animal" : "Editar animal");

        campoNome = FormularioPanel.campoTexto(null);
        comboEspecie = new JComboBox<>();
        campoRaca = FormularioPanel.campoTexto("Opcional");
        campoNascimento = FormularioPanel.campoTexto("dd/mm/aaaa (opcional)");
        campoPeso = FormularioPanel.campoTexto("Em kg (opcional)");
        comboTutor = new JComboBox<>();

        form.adicionarCampo("Nome:", campoNome);
        form.adicionarCampo("Espécie:", comboEspecie);
        form.adicionarCampo("Raça:", campoRaca);
        form.adicionarCampo("Nascimento:", campoNascimento);
        form.adicionarCampo("Peso (kg):", campoPeso);
        form.adicionarCampo("Tutor:", comboTutor);

        JButton botaoCancelar = new JButton("Cancelar");
        JButton botaoSalvar = new JButton("Salvar");
        botaoSalvar.setBackground(UIManager.getColor("Component.accentColor"));
        botaoSalvar.setForeground(Color.WHITE);

        if (id == null) {
            form.adicionarBotoes(botaoCancelar, botaoSalvar);
        } else {
            JButton botaoExcluir = new JButton("Excluir");
            botaoExcluir.addActionListener(e -> excluir());
            form.adicionarBotoes(botaoCancelar, botaoSalvar, botaoExcluir);
        }

        add(form, BorderLayout.CENTER);

        botaoSalvar.addActionListener(e -> salvar());
        botaoCancelar.addActionListener(e -> conteudo.mostrarAnimais());
    }

    private void carregarCombos() {
        try {
            for (Especie especie : controller.obterEspecies()) comboEspecie.addItem(especie);
            for (Tutor tutor : controller.obterTutores()) comboTutor.addItem(tutor);

            if (comboEspecie.getItemCount() == 0) {
                conteudo.mensagemErro("Cadastre ao menos uma espécie antes de cadastrar animais.");
            } else if (comboTutor.getItemCount() == 0) {
                conteudo.mensagemErro("Cadastre ao menos um tutor antes de cadastrar animais.");
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar espécies e tutores. " + e.getMessage());
        }
    }

    private void carregar() {
        try {
            Animal animal = controller.obterPeloId(id);

            campoNome.setText(animal.getNome());
            campoRaca.setText(animal.getRaca());
            campoNascimento.setText(DataUtil.formatar(animal.getDataNascimento()));
            campoPeso.setText(animal.getPeso() == null ? "" : String.valueOf(animal.getPeso()));

            for (int i = 0; i < comboEspecie.getItemCount(); i++) {
                if (comboEspecie.getItemAt(i).getId().equals(animal.getEspecie().getId())) {
                    comboEspecie.setSelectedIndex(i);
                }
            }
            for (int i = 0; i < comboTutor.getItemCount(); i++) {
                if (comboTutor.getItemAt(i).getId().equals(animal.getTutor().getId())) {
                    comboTutor.setSelectedIndex(i);
                }
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar o animal. " + e.getMessage());
        }
    }

    private void salvar() {
        try {
            Animal animal = new Animal();
            animal.setId(id);
            animal.setNome(campoNome.getText());
            animal.setEspecie((Especie) comboEspecie.getSelectedItem());
            animal.setRaca(campoRaca.getText());
            animal.setDataNascimento(DataUtil.lerData(campoNascimento.getText()));
            animal.setPeso(DataUtil.lerPeso(campoPeso.getText()));
            animal.setTutor((Tutor) comboTutor.getSelectedItem());

            controller.salvar(animal);

            conteudo.mostrarAnimais();
            conteudo.mensagemNormal("Animal salvo com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro(e.getMessage());
        }
    }

    private void excluir() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir este animal?", "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resposta != JOptionPane.YES_OPTION) return;

        try {
            controller.excluir(id);

            conteudo.mostrarAnimais();
            conteudo.mensagemNormal("Animal excluído com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível excluir o animal. " + e.getMessage());
        }
    }
}
