package br.edu.univille.poo.clinica.view.componente;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/** Painel padrão dos formulários: título, linhas "rótulo + campo" e botões. */
public class FormularioPanel extends JPanel {

    private static final int LARGURA_CAMPO = 400;

    private final JPanel campos = new JPanel(new GridBagLayout());
    private final GridBagConstraints gbc = new GridBagConstraints();
    private int linha = 1;

    public FormularioPanel(String titulo) {
        setLayout(new BorderLayout());

        campos.setBorder(new EmptyBorder(15, 20, 20, 20));

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JLabel labelTitulo = new JLabel(titulo);
        labelTitulo.setFont(labelTitulo.getFont().deriveFont(Font.BOLD, 20f));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.insets = new Insets(5, 5, 15, 5);
        campos.add(labelTitulo, gbc);
        gbc.insets = new Insets(5, 5, 5, 5);

        JPanel alinhamento = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        alinhamento.add(campos);

        add(alinhamento, BorderLayout.NORTH);
    }

    public void adicionarCampo(String rotulo, JComponent campo) {
        adicionarCampo(rotulo, campo, false);
    }

    public void adicionarCampo(String rotulo, JComponent campo, boolean alinharNoTopo) {
        if (!(campo instanceof JCheckBox)) {
            campo.setPreferredSize(new Dimension(LARGURA_CAMPO, campo.getPreferredSize().height));
        }

        gbc.gridy = linha++;
        gbc.gridwidth = 1;
        gbc.anchor = alinharNoTopo ? GridBagConstraints.NORTHWEST : GridBagConstraints.WEST;

        gbc.gridx = 0;
        campos.add(new JLabel(rotulo), gbc);

        gbc.gridx = 1;
        campos.add(campo, gbc);
    }

    public void adicionarBotoes(JButton... botoes) {
        JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        for (JButton botao : botoes) {
            painelBotoes.add(botao);
        }

        gbc.gridy = linha++;
        gbc.gridx = 1;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(15, 5, 5, 5);
        campos.add(painelBotoes, gbc);
    }

    public static JTextField campoTexto(String placeholder) {
        JTextField campo = new JTextField();
        if (placeholder != null) {
            campo.putClientProperty("JTextField.placeholderText", placeholder);
        }
        return campo;
    }

}
