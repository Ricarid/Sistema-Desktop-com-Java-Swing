package br.edu.univille.poo.clinica.model.dao;

import org.sqlite.SQLiteConfig;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Objects;

public class ConnectionFactory {

    public static final String URL = "jdbc:sqlite:clinica.db";

    private static ConnectionFactory instance;
    private final SQLiteConfig config;

    private ConnectionFactory(){
        config = new SQLiteConfig();
        config.enforceForeignKeys(true);
    }

    public synchronized static ConnectionFactory getInstance(){
        if(Objects.isNull(instance)) instance = new ConnectionFactory();
        return instance;
    }

    public Connection get() throws SQLException {
        return DriverManager.getConnection(URL, config.toProperties());
    }

}
