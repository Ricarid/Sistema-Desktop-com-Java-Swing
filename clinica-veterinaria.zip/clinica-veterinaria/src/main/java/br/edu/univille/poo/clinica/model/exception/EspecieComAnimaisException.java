package br.edu.univille.poo.clinica.model.exception;

public class EspecieComAnimaisException extends RuntimeException {
    public EspecieComAnimaisException() {
        super("A espécie possui animais associados.");
    }
}
