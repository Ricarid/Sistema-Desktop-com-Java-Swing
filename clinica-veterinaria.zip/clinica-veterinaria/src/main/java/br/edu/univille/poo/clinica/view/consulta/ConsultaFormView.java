package br.edu.univille.poo.clinica.view.consulta;

import br.edu.univille.poo.clinica.control.consulta.ConsultaFormController;
import br.edu.univille.poo.clinica.model.entity.Animal;
import br.edu.univille.poo.clinica.model.entity.Consulta;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;
import br.edu.univille.poo.clinica.model.entity.Veterinario;
import br.edu.univille.poo.clinica.util.DataUtil;
import br.edu.univille.poo.clinica.view.componente.FormularioPanel;
import br.edu.univille.poo.clinica.view.principal.ConteudoPanel;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;

public class ConsultaFormView extends JPanel {

    private final ConsultaFormController controller = new ConsultaFormController();
    private final ConteudoPanel conteudo;
    private final Integer id;

    private JComboBox<Animal> comboAnimal;
    private JComboBox<Veterinario> comboVeterinario;
    private JTextField campoDataHora;
    private JTextField campoMotivo;
    private JTextArea areaDiagnostico;
    private JTextField campoValor;
    private JComboBox<StatusConsulta> comboStatus;

    public ConsultaFormView(Integer id, ConteudoPanel conteudo) {
        this.id = id;
        this.conteudo = conteudo;

        configurarLayout();
        carregarCombos();

        if (id != null) {
            carregar();
        } else {
            LocalDateTime proxima = LocalDateTime.now().plusHours(1).withMinute(0).withSecond(0).withNano(0);
            campoDataHora.setText(DataUtil.formatar(proxima));
        }
    }

    private void configurarLayout() {
        setLayout(new BorderLayout());

        FormularioPanel form = new FormularioPanel(id == null ? "Nova consulta" : "Editar consulta");

        comboAnimal = new JComboBox<>();
        comboVeterinario = new JComboBox<>();
        campoDataHora = FormularioPanel.campoTexto("dd/mm/aaaa hh:mm");
        campoMotivo = FormularioPanel.campoTexto("Ex.: Vacinação, retorno, check-up");
        areaDiagnostico = new JTextArea(4, 30);
        areaDiagnostico.setLineWrap(true);
        areaDiagnostico.setWrapStyleWord(true);
        campoValor = FormularioPanel.campoTexto("Ex.: 150,00");
        comboStatus = new JComboBox<>(StatusConsulta.values());

        form.adicionarCampo("Animal:", comboAnimal);
        form.adicionarCampo("Veterinário:", comboVeterinario);
        form.adicionarCampo("Data/hora:", campoDataHora);
        form.adicionarCampo("Motivo:", campoMotivo);
        form.adicionarCampo("Diagnóstico:", new JScrollPane(areaDiagnostico), true);
        form.adicionarCampo("Valor (R$):", campoValor);
        form.adicionarCampo("Status:", comboStatus);

        JButton botaoCancelar = new JButton("Cancelar");
        JButton botaoSalvar = new JButton("Salvar");
        botaoSalvar.setBackground(UIManager.getColor("Component.accentColor"));
        botaoSalvar.setForeground(Color.WHITE);

        if (id == null) {
            form.adicionarBotoes(botaoCancelar, botaoSalvar);
        } else {
            JButton botaoExcluir = new JButton("Excluir");
            botaoExcluir.addActionListener(e -> excluir());
            form.adicionarBotoes(botaoCancelar, botaoSalvar, botaoExcluir);
        }

        add(form, BorderLayout.CENTER);

        botaoSalvar.addActionListener(e -> salvar());
        botaoCancelar.addActionListener(e -> conteudo.mostrarConsultas());
    }

    private void carregarCombos() {
        try {
            for (Animal animal : controller.obterAnimais()) comboAnimal.addItem(animal);
            for (Veterinario vet : controller.obterVeterinariosAtivos()) comboVeterinario.addItem(vet);

            if (comboAnimal.getItemCount() == 0) {
                conteudo.mensagemErro("Cadastre ao menos um animal antes de agendar consultas.");
            } else if (comboVeterinario.getItemCount() == 0) {
                conteudo.mensagemErro("Não há veterinários ativos cadastrados.");
            }
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar animais e veterinários. " + e.getMessage());
        }
    }

    private void carregar() {
        try {
            Consulta consulta = controller.obterPeloId(id);

            selecionarAnimal(consulta.getAnimal().getId());
            selecionarVeterinario(consulta.getVeterinario());

            campoDataHora.setText(DataUtil.formatar(consulta.getDataHora()));
            campoMotivo.setText(consulta.getMotivo());
            areaDiagnostico.setText(consulta.getDiagnostico());
            campoValor.setText(consulta.getValor().toPlainString().replace('.', ','));
            comboStatus.setSelectedItem(consulta.getStatus());
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível carregar a consulta. " + e.getMessage());
        }
    }

    private void selecionarAnimal(Integer animalId) {
        for (int i = 0; i < comboAnimal.getItemCount(); i++) {
            if (comboAnimal.getItemAt(i).getId().equals(animalId)) {
                comboAnimal.setSelectedIndex(i);
                return;
            }
        }
    }

    /** Se o veterinário da consulta foi inativado depois, ele continua aparecendo na edição. */
    private void selecionarVeterinario(Veterinario vet) {
        for (int i = 0; i < comboVeterinario.getItemCount(); i++) {
            if (comboVeterinario.getItemAt(i).getId().equals(vet.getId())) {
                comboVeterinario.setSelectedIndex(i);
                return;
            }
        }
        comboVeterinario.addItem(vet);
        comboVeterinario.setSelectedItem(vet);
    }

    private void salvar() {
        try {
            Consulta consulta = new Consulta();
            consulta.setId(id);
            consulta.setAnimal((Animal) comboAnimal.getSelectedItem());
            consulta.setVeterinario((Veterinario) comboVeterinario.getSelectedItem());
            consulta.setDataHora(DataUtil.lerDataHora(campoDataHora.getText()));
            consulta.setMotivo(campoMotivo.getText());
            consulta.setDiagnostico(areaDiagnostico.getText());
            consulta.setValor(DataUtil.lerValor(campoValor.getText()));
            consulta.setStatus((StatusConsulta) comboStatus.getSelectedItem());

            controller.salvar(consulta);

            conteudo.mostrarConsultas();
            conteudo.mensagemNormal("Consulta salva com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro(e.getMessage());
        }
    }

    private void excluir() {
        int resposta = JOptionPane.showConfirmDialog(this,
                "Deseja realmente excluir esta consulta?", "Confirmar exclusão",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);

        if (resposta != JOptionPane.YES_OPTION) return;

        try {
            controller.excluir(id);

            conteudo.mostrarConsultas();
            conteudo.mensagemNormal("Consulta excluída com sucesso.");
        } catch (Exception e) {
            conteudo.mensagemErro("Não foi possível excluir a consulta. " + e.getMessage());
        }
    }
}
