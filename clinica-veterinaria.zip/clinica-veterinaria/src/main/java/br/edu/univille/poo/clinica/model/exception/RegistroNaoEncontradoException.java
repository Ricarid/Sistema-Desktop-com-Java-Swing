package br.edu.univille.poo.clinica.model.exception;

public class RegistroNaoEncontradoException extends RuntimeException {
    public RegistroNaoEncontradoException(String entidade) {
        super(entidade + " não encontrado(a).");
    }
}
