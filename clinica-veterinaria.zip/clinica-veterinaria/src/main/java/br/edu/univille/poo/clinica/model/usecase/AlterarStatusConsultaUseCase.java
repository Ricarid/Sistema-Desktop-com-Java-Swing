package br.edu.univille.poo.clinica.model.usecase;

import br.edu.univille.poo.clinica.model.dao.ConsultaDAO;
import br.edu.univille.poo.clinica.model.entity.StatusConsulta;
import br.edu.univille.poo.clinica.model.exception.RegistroNaoEncontradoException;

public class AlterarStatusConsultaUseCase {

    private final ConsultaDAO dao = new ConsultaDAO();
    private final SalvarConsultaUseCase salvarUseCase = new SalvarConsultaUseCase();

    public void executar(Integer consultaId, StatusConsulta novoStatus) {
        var consulta = dao.obterPeloId(consultaId)
                .orElseThrow(() -> new RegistroNaoEncontradoException("Consulta"));

        if (consulta.getStatus() != StatusConsulta.AGENDADA) {
            throw new IllegalArgumentException("Somente consultas agendadas podem ter o status alterado aqui.");
        }

        consulta.setStatus(novoStatus);
        salvarUseCase.executar(consulta);
    }

}
