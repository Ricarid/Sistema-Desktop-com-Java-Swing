package br.edu.univille.poo.clinica.model.entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Consulta {
    private Integer id;
    private Animal animal;
    private Veterinario veterinario;
    private LocalDateTime dataHora;
    private String motivo;
    private String diagnostico;
    private BigDecimal valor = BigDecimal.ZERO;
    private StatusConsulta status = StatusConsulta.AGENDADA;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Animal getAnimal() { return animal; }
    public void setAnimal(Animal animal) { this.animal = animal; }
    public Veterinario getVeterinario() { return veterinario; }
    public void setVeterinario(Veterinario veterinario) { this.veterinario = veterinario; }
    public LocalDateTime getDataHora() { return dataHora; }
    public void setDataHora(LocalDateTime dataHora) { this.dataHora = dataHora; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public BigDecimal getValor() { return valor; }
    public void setValor(BigDecimal valor) { this.valor = valor; }
    public StatusConsulta getStatus() { return status; }
    public void setStatus(StatusConsulta status) { this.status = status; }
}
