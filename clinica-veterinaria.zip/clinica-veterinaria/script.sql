
CREATE TABLE IF NOT EXISTS especie (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL UNIQUE COLLATE NOCASE
        );

CREATE TABLE IF NOT EXISTS tutor (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf TEXT NOT NULL UNIQUE,
            telefone TEXT NOT NULL,
            email TEXT
        );

CREATE TABLE IF NOT EXISTS animal (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            especie_id INTEGER NOT NULL,
            raca TEXT,
            data_nascimento TEXT,
            peso REAL,
            tutor_id INTEGER NOT NULL,

            FOREIGN KEY (especie_id) REFERENCES especie(id),
            FOREIGN KEY (tutor_id) REFERENCES tutor(id)
        );

CREATE TABLE IF NOT EXISTS veterinario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            crmv TEXT NOT NULL UNIQUE,
            especialidade TEXT,
            ativo INTEGER NOT NULL DEFAULT 1
        );

CREATE TABLE IF NOT EXISTS consulta (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            animal_id INTEGER NOT NULL,
            veterinario_id INTEGER NOT NULL,
            data_hora TEXT NOT NULL,
            motivo TEXT NOT NULL,
            diagnostico TEXT,
            valor REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL,

            FOREIGN KEY (animal_id) REFERENCES animal(id),
            FOREIGN KEY (veterinario_id) REFERENCES veterinario(id)
        );
